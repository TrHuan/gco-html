<div class="art-popups art-popups-login">
	<div class="popups-box">					
		<div class="popups-content">
			<div class="container">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
						<div class="popup-content">
							<div class="art-login">
								<div class="login-box">
									<div class="title-box title-login">
										<h3 class="title">Đăng nhập</h3>
										<p>Bạn vui lòng đăng nhập để thực hiện đánh giá về chúng tôi.</p>
									</div>

									<div class="content-box content-login">
										<div class="button">
											<a href="#" class="btn">
												<img src="assets/images/icon-facebook.png" alt="Facebook">
												<span>Continue width Facebook</span>
											</a>
											<a href="#" class="btn">
												<img src="assets/images/icon-google.png" alt="Google">
												<span>Continue width Google</span>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	
</div>