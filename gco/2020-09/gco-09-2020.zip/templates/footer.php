
	<footer class="footers">
		Footer
	</footer> <!-- footers -->

</div> <!-- body-main -->

<?php
	include 'templates/popups/login.php';
?>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/mobilemenu.js"></script>

<script src="assets/js/main.js"></script>

<div class="back-to-top">
	<i class="far fa-chevron-up icon" aria-hidden="true"></i>
</div>