
<div class="body-main">		
	<header class="headers">
		<?php include 'templates/headers/megamenu-mobile.php'; ?>

		<div class="header-stick">
			<?php include 'templates/headers/header-main.php'; ?>
		</div> <!--header-stick-->


		<?php include 'templates/headers/header-main.php'; ?>
	</header> <!--headers-->
	