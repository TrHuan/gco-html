<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Gco</title>

	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

	<link href="assets/css/utm-yen-tu.css" rel="stylesheet" />
	<link href="assets/css/UTMHelvetIns.css" rel="stylesheet" />
	<link href="assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/css/mobilemenu.css" rel="stylesheet" />
	<link href="assets/css/slick.css" rel="stylesheet" />
	<link href="assets/css/all.fontawesome.min.css" rel="stylesheet" />
	<link href="assets/css/styles.min.css" rel="stylesheet" />

	<link href="assets/css/customs.css" rel="stylesheet" />
	<link href="assets/css/reponsive.css" rel="stylesheet" />

	<style type="text/css">
		
	</style>
</head>