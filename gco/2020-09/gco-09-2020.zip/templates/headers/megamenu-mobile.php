<div class="megamenu megamenu-mobile-content d-lg-none">
	<div class="modal menu-content">
		<!-- Modal content -->
		<div class="modal-content animated zoomIn">
			<div class="logos-box">
				<div class="logos-content">
					<a href="index.php" title="Logo">
						<label>Seo <span>plus</span></label> 
					</a>
				</div>
			</div>	
			
			<div class="menu-close">
				<span class="close">×</span>
			</div>

			<div class="modal-body">
				<?php include 'templates/headers/nav-megamenu.php'; ?>
			</div>
		</div>
	</div>
</div> <!-- megamenu-mobile -->