jQuery(document).ready(function($) {
    $(window).on("scroll",function() {
        var hb = $('header').height();
        if ($(this).scrollTop() > hb ) {
            $('header').css({'position': 'fixed', 'background-color': '#fff', 'border-bottom': '1px solid #ebebeb'});
        } else {
            $('header').css({'position': 'absolute', 'background': 'none', 'border-bottom': 'none'});
        }
    });
});

jQuery(document).ready(function($) {

});

jQuery(document).ready(function($) {
   
});

jQuery(document).ready(function($) {
    $(window).resize(function(){
        var w_window = $(window).width();
        if (w_window >= 992) {
            
        } else {

        }
    });
});