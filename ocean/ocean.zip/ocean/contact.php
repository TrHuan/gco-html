<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Liên hệ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="contact" class="pt-50 pb-50">
		<div class="container pb-50">
			<div class="row">
				<div class="col-md-6">
					<div class="txt-contact">
						<h1>CÔNG TY TNHH TMDV DU LỊCH OCEAN</h1>
						<div class="desc">
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard of the printing and typesetting industry. </p>
							<p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
						</div>
						<div class="place">
							<ul>
								<li><img src="images/pl-1.png" class="img-fluid" alt="">109/8 Lê Lợi, Phường 4, Quận Gò Vấp, TP. HCM</li>
								<li><img src="images/pl-2.png" class="img-fluid" alt="">028.6295.9568 -  0901.455.986</li>
								<li><img src="images/pl-3.png" class="img-fluid" alt="">Info@dulichocean.vn</li>
								<li><img src="images/pl-4.png" class="img-fluid" alt="">Mã số thuế: 0123456789</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="hotline-ctn">
						<div class="box-hotline">
							<h3>TƯ VẤN TOUR TRONG NƯỚC</h3>
							<ul>
								<li>Mr. Phương: 0909 794 086</li>
								<li>Ms. Ngân: 0901 409 086</li>
								<li>Mrs. Thủy: 0903 135 386</li>
								<!-- <li>Mr. Nhi: 0901 420 186</li> -->
							</ul>
						</div>
						<div class="box-hotline">
							<h3>TƯ VẤN TOUR NƯỚC ngoài</h3>
							<ul>
								<li>Mr. Phương: 0909 794 086</li>
								<li>Ms. Ngân: 0901 409 086</li>
								<li>Mrs. Thủy: 0903 135 386</li>
								<!-- <li>Mr. Nhi: 0901 420 186</li> -->
							</ul>
						</div>
						<div class="box-hotline">
							<h3>TƯ VẤN ĐẶT VÉ MÁY BAY</h3>
							<ul>
								<li>Mr. Phương: 0909 794 086</li>
								<li>Ms. Ngân: 0901 409 086</li>
								<li>Mrs. Thủy: 0903 135 386</li>
								<!-- <li>Mr. Nhi: 0901 420 186</li> -->
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="box-form">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-6">
						<div class="form-ctn">
							<p>* Đăng ký nhận báo giá</p>
							<div class="list-form form-contact">
								<div class="item">
									<input type="text" placeholder="Họ & tên" class="inp-contact">
									<img src="images/ct-1.png" class="img-fluid" alt="">
								</div>
								<div class="item">
									<input type="text" placeholder="Email" class="inp-contact">
									<img src="images/ct-2.png" class="img-fluid" alt="">
								</div>
								<div class="item">
									<input type="text" placeholder="Số điện thoại" class="inp-contact">
									<img src="images/ct-3.png" class="img-fluid" alt="">
								</div>
								<div class="item">
									<textarea name="" id="" cols="30" rows="10" placeholder="Nội dung" class="inp-contact"></textarea>
									<img src="images/ct-4.png" class="img-fluid" alt="">
								</div>
								<div class="item">
									<input type="submit" value="Đăng ký" class="btn-submit">
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 text-center">
						<h2>Đặt tour cho riêng bạn</h2>
						<p>Để lại thông tin cá nhân và lịch trình đề xuất. Chúng tôi sẽ  liên lạc lại với bạn</p>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>