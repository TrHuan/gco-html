<?php include 'header.php';?>

<main>

	<section id="breadcrumbs">

		<!-- <div class="avarta-bread"><img src="images/bread-2.png" class="img-fluid w-100" alt=""></div>  -->

		<div class="container">

			<div class="bread">

				<ul class="list-inline">

					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>

					<li class="list-inline-item"><a title="" href="tour.php">Tour trong nước</a></li>

					<li class="list-inline-item"><a title="" href="tour-detail.php">Chi tiết Tour trong nước</a></li>

					<li class="list-inline-item"><a title="" href="javascript:0">Đặt tour</a></li>

				</ul>

			</div>

		</div>

	</section>

	<section id="tour-detail" class="pt-50 pb-50">

		<div class="container">

			<div class="content">

				<h1 class="title-tour text-center text-uppercase">SÀI GÒN - NHA TRANG – CITY TOUR – BÌNH BA - VINPEARLAND (3N4Đ)</h1>

				<div class="info-book">

					<h3>Thông tin cơ bản tour</h3>

					<div class="row">

						<div class="col-md-6">

							<div class="txt-tour">

								<ul>

									<li><p>Tên tour:</p><span> SÀI GÒN - NHA TRANG – CITY TOUR – BÌNH BA - VINPEARLAND, 3N4Đ,</span></li>

									<li><p>Phương tiện di chuyển:</p><span>Đi xe giường nằm</span></li>

									<li><p>Phương tiện tham quan:</p><span>Maza 3</span></li>

									<li><p>Ngày khởi hành:</p><span>20/02/2020</span></li>

									<!-- <li><p>Điểm khởi hành:</p><span>Hồ Chí Minh</span></li> -->

								</ul>

							</div>

						</div>

						<div class="col-md-6">

							<div class="txt-tour"> 

								<ul>

									<li><p>Mã tour:</p><span>SGVP-NT-3N4D</span></li>

									<li><p>Điểm khởi hành:</p><span>Hồ Chí Minh</span></li>

									<li><p>Điểm kết thúc:</p><span>Hồ Chí Minh</span></li>

									<li><p>Ngày kết thúc: </p><span>4 ngày 3 đêm</span></li>

								</ul>

							</div>

						</div>

					</div>

				</div>

				<div class="info-book hide-scr">

								<div class="head-price">

									<h4>Bảng giá tour </h4>

									<p>(chưa bao gồm vé máy bay phụ thuộc từng thời điểm)</p>

								</div>

								<div class="tb-scroll">

									<table class="table table-bordered table-hover dt-responsive table-price">

								        <tbody>

									        <tr>

									            <td rowspan="2"><p>Tiêu chuẩn</p></td>

									            <td rowspan="2">Người lớn</td>

									            <td rowspan="2">Trẻ em <br>( 5 - 10 tuổi )</td>

									            <td rowspan="2">Trẻ em <br>( 2 - 5 tuổi )</td>

									            <td colspan="2">Phụ thu ( VNĐ/ Khách)</td> 

									        </tr>

									        <tr>

									            <td>Phòng đơn</td>

									            <td>Khách nước ngoài</td>

									        </tr>

									        <tr>

									            <td><p>Khách sạn 2*</p></td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									        </tr>

									        <tr>

									            <td><p>Khách sạn 3*</p></td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									        </tr>

									        <tr>

									            <td><p>Khách sạn 4*</p></td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									            <td>3.000.000đ</td>

									        </tr>

									        <tr>

									            <td><p>Khách sạn 5*</p></td>

									            <td></td>

									            <td></td>

									            <td></td>

									            <td></td>

									            <td></td>

									        </tr>

									        <tr>

									            <td colspan="6"><p>Lưu ý: Các ngày khởi hành và kết thúc tour, Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</p></td>

									            <!-- <td colspan="6"></td>  -->

									        </tr>

								        </tbody>

								   	</table>

							   	</div>

							   	<div class="clc-date text-right">

							   		<a title="" href="book-tour.php">Đặt Tour</a>

							   	</div>

							   	<div class="list-info-price">

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-1.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Giá tour khách lẻ</strong></p>

							   				<p class="price">5.000.000đ</p>

							   			</div>

							   		</div>

							   		<!-- <div class="item">

							   			<div class="p-icon"><img src="images/pr-2.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Các ngày khởi hành và kết thúc tour</strong></p>

							   				<ul>

							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>

							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>

							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>

							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-3.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Giá bao gồm</strong></p>

							   				<ul>

							   					<li>Khách sạn tối thiểu 3*, phòng đôi tiêu chuẩn với những tiện nghi riêng</li>

							   					<li>Hướng dẫn viên nhiệt tình, chuyên nghiệp theo suốt hành trình</li>

							   					<li>Bữa sáng kiểu Âu tại khách sạn</li>

							   					<li>Xe du lịch hiện đại, tài xế chuyên nghiệp và giàu kinh nghiệm</li>

							   					<li>Điểm tập trung tiện lợi trong suốt hành trình</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-4.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Giá không bao gồm:</strong></p>

							   				<ul>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-5.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Trẻ em:</strong></p>

							   				<ul>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-6.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Ký hợp đồng và đặt cọc tour</strong></p>

							   				<ul>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="item">

							   			<div class="p-icon"><img src="images/pr-7.png" class="img-fluid" alt=""></div>

							   			<div class="p-info">

							   				<p><strong>Khách sạn</strong></p>

							   				<ul>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>

							   					<li>Tiền tip cho HDV và lái xe.</li>

							   				</ul>

							   			</div>

							   		</div>

							   		<div class="list-col">

							   			<div class="row">

							   				<div class="col-md-6">

							   					<div class="item-col">

							   						<div class="head-pr"><img src="images/ppr-1.png" class="img-fluid" alt=""><span>Vé tham quan &amp; thuế phí</span></div>

							   						<div class="txt-col">

							   							<h4>BẢNG GIÁ CỦA CÁC HOẠT ĐỘNG THAM QUAN</h4>

							   							<ul>

							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>

							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>

							   								<li>Bữa trưa với món Mỳ Ý truyền thống (Black Sauce Spaghetti Menu, bao gồm salad, nước sốt màu đen spaghetti, mực chiên và tôm, món tráng miệng và nước (Venice): €20</li>

							   								<li>Thăm quan đấu trường La Mã Coliseum với hướng dẫn địa Phương (Rome): €35</li>

							   								<li>Firentino Steak Menu, bao gồm salad, mì ống tự chế biến bởi nhà hàng, 250g thịt nướng Fiorentina steak, tráng miệng và rươu (Florence): €30</li>

							   								<li>Tour thăm quan nhà nguyện Sistine Chapel với hướng dẫn địa phương, bảo tàng Vativan và nhà thờ thánh St. Peter (Rome): €45</li>

							   							</ul>

							   						</div>

							   					</div>

							   				</div>

							   				<div class="col-md-6">

							   					<div class="item-col">

							   						<div class="head-pr"><img src="images/ppr-2.png" class="img-fluid" alt=""><span>Địa điểm tập trung</span></div>

							   						<div class="txt-col">

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   						</div>

							   					</div>

							   				</div>

							   				<div class="col-md-6">

							   					<div class="item-col">

							   						<div class="head-pr"><img src="images/ppr-3.png" class="img-fluid" alt=""><span>Điểm tiễn khách</span></div>

							   						<div class="txt-col">

							   							<h4>BẢNG GIÁ CỦA CÁC HOẠT ĐỘNG THAM QUAN</h4>

							   							<ul>

							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>

							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>

							   								<li>Bữa trưa với món Mỳ Ý truyền thống (Black Sauce Spaghetti Menu, bao gồm salad, nước sốt màu đen spaghetti, mực chiên và tôm, món tráng miệng và nước (Venice): €20</li>

							   								<li>Thăm quan đấu trường La Mã Coliseum với hướng dẫn địa Phương (Rome): €35</li>

							   								<li>Firentino Steak Menu, bao gồm salad, mì ống tự chế biến bởi nhà hàng, 250g thịt nướng Fiorentina steak, tráng miệng và rươu (Florence): €30</li>

							   								<li>Tour thăm quan nhà nguyện Sistine Chapel với hướng dẫn địa phương, bảo tàng Vativan và nhà thờ thánh St. Peter (Rome): €45</li>

							   							</ul>

							   						</div>

							   					</div>

							   				</div>

							   				<div class="col-md-6">

							   					<div class="item-col">

							   						<div class="head-pr"><img src="images/ppr-4.png" class="img-fluid" alt=""><span>Dịch vụ khác</span></div>

							   						<div class="txt-col">

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   							<div class="item-txt">

							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>

								   							<p>Điểm gặp: McDonalds Restaurant</p>

								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>

								   							<p>Metro: Line 5, 6 &amp; 7</p>

								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>

							   							</div>

							   						</div>

							   					</div>

							   				</div>

							   			</div>

							   		</div> -->

							   	</div>

							</div>

				<div class="info-book">

					<h3>Thông tin khách hàng</h3>

					<div class="info-per">

						<div class="row">

							<div class="col-md-6">

								<div class="item">

									<label>Họ tên (*)</label><input type="text">

								</div>

							</div>

							<div class="col-md-6">

								<div class="item">

									<label>Email (*)</label><input type="text">

								</div>

							</div>

							<div class="col-md-6">

								<div class="item">

									<label>Điện thoại (*)</label><input type="text">

								</div>

							</div>

							<div class="col-md-6">

								<div class="item">

									<label>Điện thoại khác</label><input type="text">

								</div>

							</div>

							<div class="col-md-6">

								<div class="item">

									<label>Địa chỉ (*)</label><textarea name="" id="" cols="30" rows="10"></textarea>

								</div>

							</div>

							<div class="col-md-6">

								<div class="item">

									<label>Ghi chú</label><textarea name="" id="" cols="30" rows="10"></textarea>

								</div>

							</div>

						</div>

					</div>

				</div>

				<div class="info-book">

					<h3>Danh sách khách hàng đi tour</h3>

					<div class="tb-scroll">

						<table class="table table-bordered table-hover dt-responsive w-100 table-per">

					        <thead>

						        <tr>

						            <th>STT</th>

						            <th>Họ tên (*)</th>

						            <th>Ngày sinh (*)</th>

						            <th>Địa chỉ</th>

						            <th>Điện thoại</th>

						            <th>Giới tính</th>

						            <th>Loại khách</th>

						            <th>Độ tuổi</th>

						            <th>Phòng đơn</th>

						            <th>Visa</th>

						            <th>Chất lượng phòng</th>

						        </tr>

					        </thead>

					        <tbody>

						        <tr>

						            <td class="text-center">1</td>

						            <td><input type="text"></td>

						            <td>

						            	<div class="form-group">

									        <div class='input-group date date-birth' id='datetimepicker2'>

									        	<input type='text' placeholder="" class="inp_date" />

									        	<span class="input-group-addon"><i class="fa fa-calendar"></i></span>

									        </div>

									    </div>

						            </td>

						            <td><input type="text"></td>

						            <td><input type="text"></td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Nam</option>

						            		<option value="">Nữ</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Việt Nam</option>

						            		<option value="">Nước ngoài</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">người lớn</option>

						            		<option value="">Trẻ em</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Không</option>

						            		<option value="">Có</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Không</option>

						            		<option value="">Có</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">3*</option>

						            		<option value="">4*</option>

						            		<option value="">5*</option>

						            	</select>

						            </td>

						        </tr>

						        <tr>

						            <td class="text-center">2</td>

						            <td><input type="text"></td>

						            <td>

						            	<div class="form-group">

									        <div class='input-group date date-birth' id='datetimepicker2'>

									        	<input type='text' placeholder="" class="inp_date" />

									        	<span class="input-group-addon"><i class="fa fa-calendar"></i></span>

									        </div>

									    </div>

						            </td>

						            <td><input type="text"></td>

						            <td><input type="text"></td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Nam</option>

						            		<option value="">Nữ</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Việt Nam</option>

						            		<option value="">Nước ngoài</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">người lớn</option>

						            		<option value="">Trẻ em</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Không</option>

						            		<option value="">Có</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">Không</option>

						            		<option value="">Có</option>

						            	</select>

						            </td>

						            <td>

						            	<select name="" id="">

						            		<option value="">3*</option>

						            		<option value="">4*</option>

						            		<option value="">5*</option>

						            	</select>

						            </td>

						        </tr>

					        </tbody>

						</table>

					</div>

					<div class="clc-add text-right"><a title="" href="">Thêm</a></div>

				</div>

				<div class="info-book">

					<h3>Hình thức thanh toán</h3>

					<div class="method-pay">

						<ul>

							<li><input type="radio" name="mt-1" id="mt-1" checked><label for="mt-1">Chuyển khoản qua ngân hàng</label></li>

<!--							<li><input type="radio" name="mt-1" id="mt-2"><label for="mt-2">Thu tiền tận nơi</label></li>-->

							<li><input type="radio" name="mt-1" id="mt-3"><label for="mt-3">Tại văn phòng chúng tôi</label></li>

						</ul>

					</div>

					<form action="book-tour-done.php">

						<div class="book-now"><input type="submit" value="Đặt Tour" class="clc-book"></div>

					</form>

				</div>

			</div>

		</div>

	</section>

</main>

<?php include 'footer.php';?>