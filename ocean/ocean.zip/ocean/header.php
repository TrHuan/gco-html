<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OCEAN</title>
    <!--link css-->
    <link rel="stylesheet" type="text/css" title="" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" title="" href="css/font-awesome.css">
    <link rel="stylesheet" type="text/css" title="" href="css/slick.min.css">
    <link rel="stylesheet" type="text/css" title="" href="css/slick-theme.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="css/date-time.css" />
    <link rel="stylesheet" href="css/jquery.mmenu.all.css"> 
    <link rel="stylesheet" href="css/swiper.min.css">
    <link rel="stylesheet" type="text/css" title="" href="css/style.css">
    <link rel="stylesheet" type="text/css" title="" href="css/responsive.css">

    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body> 
    <header> 
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="top-phone"><i class="fa fa-phone"></i> <span>Hotline hỗ trợ: 028.62959568  -  0901455986</span></div>
                    </div>
                    <div class="col-md-7">
                        <div class="social">
                            <ul class="list-inline text-right">
                                <li class="list-inline-item"><a title="" href=""><i class="fa fa-envelope"></i> <span>Email: Info@dulichocean.vn</span></a></li>
                                <li class="list-inline-item"><a title="" href=""><i class="fa fa-facebook"></i></a></li>
                                <li class="list-inline-item"><a title="" href=""><i class="fa fa-youtube-play"></i></a></li>
                                <li class="list-inline-item"><a title="" href=""><i class="fa fa-instagram"></i></a></li>
                                <li class="list-inline-item"><a title="" href=""><i class="fa fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-menu">
            <div class="container">
                <div class="row">
                    <div class="col-md-2">
                        <div class="logo"><a title="" href="index.php"><img src="images/logo.png" class="img-fluid" alt=""></a></div>
                    </div>
                    <div class="col-md-10">
                        <ul>
                            <li>
                                <a title="" href="tour.php"><img src="images/menu01.png" class="img-fluid" alt=""><span>Tour trong nước</span></a>
                                <ul>
                                    <li>
                                        <a title="" href="">Miền Bắc <i class="fa fa-chevron-right"></i></a>
                                        <ul>
                                            <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                            <li><a title="" href="tour.php">Nha Trang</a></li>
                                            <li><a title="" href="tour.php">Phan Thiết</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a title="" href="tour.php">Miền Trung <i class="fa fa-chevron-right"></i></a>
                                        <ul>
                                            <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                            <li><a title="" href="tour.php">Nha Trang</a></li>
                                            <li><a title="" href="tour.php">Phan Thiết</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a title="" href="tour.php">Miền Nam <i class="fa fa-chevron-right"></i></a>
                                        <ul>
                                            <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                            <li><a title="" href="tour.php">Nha Trang</a></li>
                                            <li><a title="" href="tour.php">Phan Thiết</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a title="" href="tour.php"><img src="images/menu02.png" class="img-fluid" alt=""><span>Tour ngoài nước</span></a></li>
                            <li><a title="" href=""><img src="images/menu03.png" class="img-fluid" alt=""><span>Vé máy bay </span></a></li>
                            <li>
                                <a title="" href="service.php"><img src="images/menu04.png" class="img-fluid" alt=""><span>Dịch vụ khác</span></a>
                                <ul>
                                    <li><a title="" href="service-thuexe.php">Dịch vụ thuê xe</a></li>
                                    <li><a title="" href="service-kh.php">Dịch vụ đặt phòng khách sạn</a></li>
                                    <li><a title="" href="service-sukien.php">Tổ chức sự kiện</a></li>
                                    <li><a title="" href="service-building.php">Team building</a></li>
                                    <li><a title="" href="service-mc.php">Thuê MC – HDV</a></li>
                                    <li><a title="" href="service-thuevatdung.php">Thuê vật dụng team building</a></li>
                                </ul>
                            </li>
                            <li><a title="" href="news.php"><img src="images/menu05.png" class="img-fluid" alt=""><span>Tin tức</span></a></li>
                            <li><a title="" href="news.php"><img src="images/menu06.png" class="img-fluid" alt=""><span>Blog du lịch </span></a></li>
                            <li><a title="" href="contact.php"><img src="images/menu07.png" class="img-fluid" alt=""><span> Liên hệ</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="menu-mobile" style="display: none;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-6 col-sm-6">
                        <div class="logo"> 
                            <a title="" href="index.php"><img alt="" src="images/logo.png" class="img-fluid avarta-logo" alt=""></a>
                        </div>
                    </div>
                    <div class="col-md-6 col-6 col-sm-6">
                        <div class="right">
                            <div class="header">
                                <a title="" href="#menu"><i class="fa fa-bars"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav id="menu">
                <ul>
                    <li>
                        <a title="" href="tour.php"><span>Tour trong nước</span></a>
                        <ul>
                            <li>
                                <a title="" href="tour.php">Miền Bắc</a>
                                <ul>
                                    <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                    <li><a title="" href="tour.php">Nha Trang</a></li>
                                    <li><a title="" href="tour.php">Phan Thiết</a></li>
                                </ul>
                            </li>
                            <li>
                                <a title="" href="tour.php">Miền Trung</a>
                                <ul>
                                    <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                    <li><a title="" href="tour.php">Nha Trang</a></li>
                                    <li><a title="" href="tour.php">Phan Thiết</a></li>
                                </ul>
                            </li>
                            <li>
                                <a title="" href="tour.php">Miền Nam></a>
                                <ul>
                                    <li><a title="" href="tour.php">Đà Nẵng</a></li>
                                    <li><a title="" href="tour.php">Nha Trang</a></li>
                                    <li><a title="" href="tour.php">Phan Thiết</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a title="" href="tour.php"><span>Tour ngoài nước</span></a></li>
                    <li><a title="" href=""><span>Vé máy bay </span></a></li>
                    <li>
                        <a title="" href="service.php"><span>Dịch vụ khác</span></a>
                        <ul>
                            <li><a title="" href="service-thuexe.php">Dịch vụ thuê xe</a></li>
                            <li><a title="" href="service-kh.php">Dịch vụ đặt phòng khách sạn</a></li>
                            <li><a title="" href="service-sukien.php">Tổ chức sự kiện</a></li>
                            <li><a title="" href="service-building.php">Team building</a></li>
                            <li><a title="" href="service-mc.php">Thuê MC – HDV</a></li>
                            <li><a title="" href="service-thuevatdung.php">Thuê vật dụng team building</a></li>
                        </ul>
                    </li>
                    <li><a title="" href="news.php">Tin tức</a></li>
                    <li><a title="" href="news.php">Blog du lịch</a></li>
                    <li><a title="" href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>