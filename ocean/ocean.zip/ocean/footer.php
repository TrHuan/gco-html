<footer>
	<div class="img-ft"><img src="images/ft.png" class="img-fluid w-100" alt=""></div>
	<div class="fix-mx fx-zalo">
		<ul>
			<li><a href=""><img src="images/phone.png" width="50" height="50" class="img-fluid" alt=""></a></li>
			<li><a href=""><img src="images/zalo.png" width="50" height="50" class="img-fluid" alt=""></a></li>
			<li><a href=""><img src="images/mess.png" width="50" height="50" class="img-fluid" alt=""></a></li>
		</ul>
	</div>
	<div class="cate-list">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4 col-6">
					<ul>
						<li><a title="" href="tour.php">Du lịch Phú Quốc</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Lạt</a></li>
						<li><a title="" href="tour.php">Du lịch Đà Nẵng</a></li>
						<li><a title="" href="tour.php">Du lịch Phan Thiết</a></li>
						<li><a title="" href="tour.php">Du lịch Vũng Tàu</a></li>
						<li><a title="" href="tour.php">Du lịch Nha Trang</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="info-footer">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-4">
					<div class="item">
						<div class="title-ft title-per">
							<h2>CÔNG TY TNHH TMDV DU LỊCH OCEAN</h2>
<!--							<div class="desc">Ocean Tourism là công ty hoạt động trong lĩnh vực du lịch. Chúng tôi cung cấp các tour du lịch trong và ngoài nước, dịch vụ đặt vé máy bay, dịch vụ cho thuê xe du lịch,...</div>-->
							<ul>
								<li>Địa chỉ: 109/8 Lê Lợi, Phường 4, Quận Gò Vấp, TP. HCM</li>
								<li>Hotline: 028.62959568 -  0901455986</li>
								<li>Email:  Info@dulichocean.vn</li>
								<li>Mã số thuế: 0313999622</li>
							</ul>
							<div class="bct"><img src="images/bct.png" class="img-fluid" alt=""></div>
						</div>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="item">
						<div class="title-ft">
							<h2>Dịch vụ</h2>
							<ul>
								<li><a title="" href="tour.php">Tour trong nước</a></li>
								<li><a title="" href="tour.php">Tour nước ngoài</a></li>
								<li><a title="" href="">Vé máy bay</a></li>
								<li><a title="" href="service-sukien.php">Tổ chức sự kiện</a></li>
								<li><a title="" href="service-building.php">Team building</a></li>
								<li><a title="" href="service-thuexe.php">Thuê xe</a></li>
								<li><a title="" href="service-kh.php">Đặt phòng khách sạn</a></li>
								<li><a title="" href="service-thuevatdung.php">Thuê vật dụng Team building</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="item">
						<div class="title-ft">
							<h2>liên hệ</h2>
							<ul>
								<li><a title="" href="">Giới thiệu </a></li>
								<li><a title="" href="">Liên hệ </a></li>
								<li><a title="" href="">Chi nhánh</a></li>
								<li><a title="" href="">Điều khoản chung</a></li>
								<li><a title="" href="">Hưỡng dẫn đặt online</a></li>
								<li><a title="" href="">Quy định thanh toán</a></li>
								<li><a title="" href="">Tuyển dụng</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="item">
						<div class="title-ft">
							<h2>Chăm sóc khách hàng</h2>
							<ul>
								<li><a title="" href="">Voucher du lịch</a></li>
								<li><a title="" href="">Bảo hiểm du lịch</a></li>
								<li><a title="" href="">Ý kiến khách hàng</a></li>
								<li><a title="" href="">Phiếu góp ý</a></li>
							</ul>
							<div class="social">
								<ul class="list-inline">
									<li class="list-inline-item"><a title="" href=""><img src="images/sc-1.png" class="img-fluid" alt=""></a></li>
									<li class="list-inline-item"><a title="" href=""><img src="images/sc-2.png" class="img-fluid" alt=""></a></li>
									<li class="list-inline-item"><a title="" href=""><img src="images/sc-3.png" class="img-fluid" alt=""></a></li>
								</ul>
							</div>
							<p class="view">Lượt truy cập: 10. 068 lượt</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="mxh">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6 col-sm-6 ">
					<h4>Google map</h4>
					<img src="images/mx-1.png" class="img-fluid w-100" alt="">
				</div>
				<div class="col-md-6 col-sm-6 ">
					<h4>Fanpage</h4>
					<img src="images/mx-2.png" class="img-fluid w-100" alt="">
				</div>
			</div>
		</div>
	</div>
	<div class="pay text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-1.png" class="img-fluid" alt=""></a></div>
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-2.png" class="img-fluid" alt=""></a></div>
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-3.png" class="img-fluid" alt=""></a></div>
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-4.png" class="img-fluid" alt=""></a></div>
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-5.png" class="img-fluid" alt=""></a></div>
				<div class="col-md-2 col-sm-2 col-2"><a title="" href=""><img src="images/pay-6.png" class="img-fluid" alt=""></a></div>
			</div>
		</div>
	</div>
</footer>
<!--Link js-->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/slick.min.js"></script>
<script src="js/swiper.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
<script type="text/javascript" src="js/moment-with-locales.js"></script>
<script type="text/javascript" src="js/datetimepicker.js"></script>
<script type="text/javascript" src="js/jquery.mmenu.all.js"></script>
<script type="text/javascript" src="js/private.js"></script>
</body>
</html>