<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="avarta-bread"><img src="images/bread-2.png" class="img-fluid w-100" alt=""></div>
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="tour.php">Tour trong nước</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Chi tiết Tour trong nước</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="tour-detail" class="pt-50 pb-50">
		<div class="container">
			<div class="content">
				<h1 class="title-tour text-center text-uppercase">PHÚ QUốC - Cáp TREO HòN THƠM -SANATO (3N3Đ)</h1>
				<div class="clc-src">
					<ul>
						<li><a title="" href="#tour-1" class="active">Giới thiệu chung</a></li>
						<li><a title="" href="#tour-2">Lịch trình chi tiết</a></li>
						<li><a title="" href="#tour-3">Chi tiết giá</a></li>
						<li><a title="" href="#tour-4">Hình ảnh</a></li>
						<li><a title="" href="#tour-5">Tour khác</a></li>
					</ul>
				</div>
				<div class="detail">
					<div class="content-detail">
						<div class="box-detail-tour">
							<div class="preview pb-50" id="tour-1">
								<div class="row">
									<div class="col-lg-7 col-md-6 col-sm-6">
										<div class="slide-preview">
											<div class="slider-for">
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <div class="play-vid"><a title="" href="javascript:0" data-toggle="modal" data-target="#myModal-video"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div>
				                                </div>
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <!-- <div class="play-vid"><a title="" href="javascript:0"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div> -->
				                                </div> 
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <!-- <div class="play-vid"><a title="" href="javascript:0"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div>  -->
				                                </div>
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <!-- <div class="play-vid"><a title="" href="javascript:0"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div>  -->
				                                </div>
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <!-- <div class="play-vid"><a title="" href="javascript:0"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div>  -->
				                                </div>
				                                <div class="carousel-item">
				                                    <img src="images/thumb-1.png" class="img-fluid" width="100%" alt="Third slide">
				                                    <!-- <div class="play-vid"><a title="" href="javascript:0"><img src="images/play-slide.png" class="img-fluid" alt=""></a></div>  -->
				                                </div>
				                            </div>
				                            <div class="slider-nav">
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-2.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-3.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-4.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-2.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-3.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                                 <div class="clc">
				                                 	<div class="item"><img class="img-fluid" src="images/thumb-4.png" width="100%" alt="Third slide"></div>
				                                 </div>
				                            </div>
										</div>


										<div class="modal fade" id="myModal-video">
										  <div class="modal-dialog modal-video">
										    <div class="modal-content">
										      <div class="modal-body">
										      	<button type="button" class="close" data-dismiss="modal">&times;</button>
										        <div class="content-popup">
										        	<iframe width="1195" height="672" src="https://www.youtube.com/embed/2GwhdLY2f3E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										        </div>
										      </div>
										    </div>
										  </div>
										</div>
									</div>


									<div class="col-lg-5 col-md-6 col-sm-6">
										<div class="info-preview">
											<div class="box_preview">
                                                <div class="row" style="width: 100%">
                                                    <div class="col-md-6">
                                                        <div class="vote">
                                                            <p>Đánh giá</p>
                                                            <img src="images/vote-1.png" class="img-fluid" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="vote">
                                                            <p>Mã tour</p>
                                                            <p class="font-weight-bold mgt-5">MT001</p>
                                                        </div>
                                                    </div>
                                                </div>
											</div>
											<div class="box_preview">
												<div class="i-box">
													<div class="icon"><img src="images/w-1.png" class="img-fluid" alt=""></div>
												</div>
												<div class="i-text">
													<p>Giá tour khách lẻ</p>
													<p class="price"><strong>5.000.000đ</strong></p>
													<ul>
														<li>Trừ ngay 3 triệu với khách hàng đã có visa</li>
														<li>Tặng 4 triệu VNĐ / khách hàng ký hợp đồng + cọc trong thời gian VITM 2020 hoặc trước 120 ngày</li>
														<li>Tặng 1 triệu VNĐ / khách hàng hợp đồng + cọc trước 45 ngày.</li>
														<li>Tặng thêm 1 triệu VND / khách hàng đăng ký theo nhóm 5 người trở lên.</li>
													</ul>
												</div>
											</div>
											<div class="box_preview">
												<div class="i-box">
													<div class="icon"><img src="images/w-2.png" class="img-fluid" alt=""></div>
												</div>
												<div class="i-text">
													<p>Thời gian</p>
													<p><strong>7 ngày 6 đêm</strong></p>
												</div>
											</div>
											<div class="box_preview">
												<div class="i-box">
													<div class="icon"><img src="images/w-3.png" class="img-fluid" alt=""></div>
												</div>
												<div class="i-text">
													<p>Phương tiện</p>
													<p><strong>Vietnam Airline</strong></p>
												</div>
											</div>
											<div class="box_preview">
												<div class="i-box">
													<div class="icon"><img src="images/w-4.png" class="img-fluid" alt=""></div>
												</div>
												<div class="i-text">
													<p>Ngày khởi hành</p>
													<p><strong>20/04/2020</strong></p>
												</div>
											</div>
											<div class="box_preview">
												<div class="i-box">
													<div class="icon"><img src="images/w-5.png" class="img-fluid" alt=""></div>
												</div>
												<div class="i-text">
													<p>Lịch trình</p>
													<ul class="list-inline">
														<li class="list-inline-item"><a title="" href="javascript:0">Đan Mạch </a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Na Uy</a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Đan Mạch </a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Na Uy</a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Đan Mạch </a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Na Uy</a></li>
														<li class="list-inline-item"><a title="" href="javascript:0">Đan Mạch </a></li>
													</ul>
												</div>
											</div>
										</div>
										<div class="book-tour"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
									</div>
								</div>
							</div>
						</div>
						<div class="box-scroll pb-50">
							<div class="title-src">Trải nghiệm độc đáo <a title="" href="javascript:0"><img src="images/close.png" class="img-fluid" alt=""></a></div>
							<ul class="hide-scr">
								<li>Thuỵ Sỹ: cầu gỗ cổ Chapel.</li>
								<li>Milan: nhà thờ Duomo lớn nhất Milan, khu trung tâm mua sắm Vittorio Emanuele II</li>
								<li>Venice: quảng trường San Macro, cầu Than Thở, trình diễn chế tác thuỷ tinh Murano.</li>
								<li>Vatican: nhà thờ thánh Peter, đài phun nước Trevi, quảng trường Tây Ban Nha, đấu trường Colosseum, khải hoàn môn Constantine.</li>
								<li>Florence: quảng trường Michelangelo, cầu Vechhio, nhà thờ Đức Mẹ, tháp nghiêng Pisa.</li>
								<li>Milan: nhà thờ Duomo lớn nhất Milan, khu trung tâm mua sắm Vittorio Emanuele II</li>
								<li>Venice: quảng trường San Macro, cầu Than Thở, trình diễn chế tác thuỷ tinh Murano.</li>
								<li>Vatican: nhà thờ thánh Peter, đài phun nước Trevi, quảng trường Tây Ban Nha, đấu trường Colosseum, khải hoàn môn Constantine.</li>
								<li>Florence: quảng trường Michelangelo, cầu Vechhio, nhà thờ Đức Mẹ, tháp nghiêng Pisa.</li>
							</ul>
						</div>
						<div class="box-scroll pb-50"  id="tour-2">
							<div class="title-src">Lịch trình chi tiết <a title="" href="javascript:0"><img src="images/close.png" class="img-fluid" alt=""></a></div>
							<div id="accordion" class="hide-scr">
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>1</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-1">
									        <h5 class="mb-0">
										        <button class="btn btn-link" data-toggle="collapse" data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-1">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-1" class="collapse show" aria-labelledby="heading-1" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>2</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-2">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="true" aria-controls="collapse-2">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-2" class="collapse" aria-labelledby="heading-2" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>3</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-3">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-3" aria-expanded="true" aria-controls="collapse-3">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-3" class="collapse" aria-labelledby="heading-3" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>4</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-4">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-4" aria-expanded="true" aria-controls="collapse-4">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-4" class="collapse" aria-labelledby="heading-4" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>5</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-5">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-5" aria-expanded="true" aria-controls="collapse-5">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-5" class="collapse" aria-labelledby="heading-5" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>6</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-6">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-6" aria-expanded="true" aria-controls="collapse-6">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-6" class="collapse" aria-labelledby="heading-6" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
								<div class="item-accr">
									<div class="c-icon"><img src="images/cal.png" class="img-fluid" alt=""><span>7</span></div>
								    <div class="card">
									    <div class="card-header" id="heading-7">
									        <h5 class="mb-0">
										        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse-7" aria-expanded="true" aria-controls="collapse-7">Thứ hai: Venice - Rome (550 km)</button>
									        </h5>
									    </div>
									    <div id="collapse-7" class="collapse" aria-labelledby="heading-7" data-parent="#accordion">
									        <div class="card-body">
									        	<div class="avarta-coll"><img src="images/tg-1.png" class="img-fluid w-100" alt=""></div>
									        	<div class="info-coll">
									        		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
									        	</div>
									        </div>
									    </div>
								    </div>
								</div>
							 </div>
						</div>
						<div class="box-scroll pb-50" id="tour-3">
							<div class="title-src">Chi tiết giá <a title="" href="javascript:0"><img src="images/close.png" class="img-fluid" alt=""></a></div>
							<div class="info-book hide-scr">
								<div class="head-price">
									<h4>Bảng giá tour </h4>
									<p>(chưa bao gồm vé máy bay phụ thuộc từng thời điểm)</p>
								</div>
								<div class="tb-scroll">
									<table class="table table-bordered table-hover dt-responsive table-price">
								        <tbody>
									        <tr>
									            <td rowspan="2"><p>Tiêu chuẩn</p></td>
									            <td rowspan="2">Người lớn</td>
									            <td rowspan="2">Trẻ em <br>( 5 - 10 tuổi )</td>
									            <td rowspan="2">Trẻ em <br>( 2 - 5 tuổi )</td>
									            <td colspan="2">Phụ thu ( VNĐ/ Khách)</td> 
									        </tr>
									        <tr>
									            <td>Phòng đơn</td>
									            <td>Khách nước ngoài</td>
									        </tr>
									        <tr>
									            <td><p>Khách sạn Hà Nội travel</p></td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									        </tr>
									        <tr>
									            <td><p>Khách sạn Hà Nội travel 2</p></td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									        </tr>
									        <tr>
									            <td><p>Khách sạn Hà Nội travel 3</p></td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									            <td>3.000.000đ</td>
									        </tr>
									        <tr>
									            <td><p>Khách sạn 5*</p></td>
									            <td></td>
									            <td></td>
									            <td></td>
									            <td></td>
									            <td></td>
									        </tr>
									        <tr>
									            <td colspan="6"><p>Lưu ý: Các ngày khởi hành và kết thúc tour, Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</p></td>
									            <!-- <td colspan="6"></td>  -->
									        </tr>
								        </tbody>
								   	</table>
							   	</div>
							   	<div class="clc-date text-right">
							   		<a title="" href="book-tour.php">Đặt Tour</a>
							   	</div>
							   	<div class="list-info-price">
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-1.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><strong>Giá tour khách lẻ</strong></p>
							   				<p class="price">5.000.000đ</p>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-2.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><strong>Các ngày khởi hành và kết thúc tour</strong></p>
							   				<ul>
							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>
							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>
							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>
							   					<li>Xuất phát thứ 7 hàng tuần tại Đà Nẵng</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-3.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><strong>Giá bao gồm</strong></p>
							   				<ul>
							   					<li>Khách sạn tối thiểu 3*, phòng đôi tiêu chuẩn với những tiện nghi riêng</li>
							   					<li>Hướng dẫn viên nhiệt tình, chuyên nghiệp theo suốt hành trình</li>
							   					<li>Bữa sáng kiểu Âu tại khách sạn</li>
							   					<li>Xe du lịch hiện đại, tài xế chuyên nghiệp và giàu kinh nghiệm</li>
							   					<li>Điểm tập trung tiện lợi trong suốt hành trình</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-4.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><strong>Giá không bao gồm:</strong></p>
							   				<ul>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-5.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><strong>Trẻ em:</strong></p>
							   				<ul>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-6.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><a href="" title=""><strong>Điều khoản chung</strong></a> </p>
							   				<ul>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="item">
							   			<div class="p-icon"><img src="images/pr-7.png" class="img-fluid" alt=""></div>
							   			<div class="p-info">
							   				<p><a href="" title=""><strong>Quy định thanh toán</strong></a> </p>
							   				<ul>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   					<li>Vé máy bay 2 chiều Hà Nội – Paris – Hà Nội (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Phí làm visa du lịch Pháp – visa du lịch Schengen (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Bảo hiểm du lịch cho thời gian đi tour với hạn mức quy định (dịch vụ hỗ trợ tự chọn)</li>
							   					<li>Tiền tip cho HDV và lái xe.</li>
							   				</ul>
							   			</div>
							   		</div>
							   		<div class="list-col">
							   			<div class="row">
							   				<div class="col-md-6">
							   					<div class="item-col">
							   						<div class="head-pr"><img src="images/ppr-1.png" class="img-fluid" alt=""><span>Vé tham quan & thuế phí</span></div>
							   						<div class="txt-col">
							   							<h4>BẢNG GIÁ CỦA CÁC HOẠT ĐỘNG THAM QUAN</h4>
							   							<ul>
							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>
							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>
							   								<li>Bữa trưa với món Mỳ Ý truyền thống (Black Sauce Spaghetti Menu, bao gồm salad, nước sốt màu đen spaghetti, mực chiên và tôm, món tráng miệng và nước (Venice): €20</li>
							   								<li>Thăm quan đấu trường La Mã Coliseum với hướng dẫn địa Phương (Rome): €35</li>
							   								<li>Firentino Steak Menu, bao gồm salad, mì ống tự chế biến bởi nhà hàng, 250g thịt nướng Fiorentina steak, tráng miệng và rươu (Florence): €30</li>
							   								<li>Tour thăm quan nhà nguyện Sistine Chapel với hướng dẫn địa phương, bảo tàng Vativan và nhà thờ thánh St. Peter (Rome): €45</li>
							   							</ul>
							   						</div>
							   					</div>
							   				</div>
							   				<div class="col-md-6">
							   					<div class="item-col">
							   						<div class="head-pr"><img src="images/ppr-2.png" class="img-fluid" alt=""><span>Địa điểm tập trung</span></div>
							   						<div class="txt-col">
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   						</div>
							   					</div>
							   				</div>
							   				<div class="col-md-6">
							   					<div class="item-col">
							   						<div class="head-pr"><img src="images/ppr-3.png" class="img-fluid" alt=""><span>Điểm tiễn khách</span></div>
							   						<div class="txt-col">
							   							<h4>BẢNG GIÁ CỦA CÁC HOẠT ĐỘNG THAM QUAN</h4>
							   							<ul>
							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>
							   								<li>Du thuyền Gondola tại Venice (6 người 1 thuyền): €30</li>
							   								<li>Bữa trưa với món Mỳ Ý truyền thống (Black Sauce Spaghetti Menu, bao gồm salad, nước sốt màu đen spaghetti, mực chiên và tôm, món tráng miệng và nước (Venice): €20</li>
							   								<li>Thăm quan đấu trường La Mã Coliseum với hướng dẫn địa Phương (Rome): €35</li>
							   								<li>Firentino Steak Menu, bao gồm salad, mì ống tự chế biến bởi nhà hàng, 250g thịt nướng Fiorentina steak, tráng miệng và rươu (Florence): €30</li>
							   								<li>Tour thăm quan nhà nguyện Sistine Chapel với hướng dẫn địa phương, bảo tàng Vativan và nhà thờ thánh St. Peter (Rome): €45</li>
							   							</ul>
							   						</div>
							   					</div>
							   				</div>
							   				<div class="col-md-6">
							   					<div class="item-col">
							   						<div class="head-pr"><img src="images/ppr-4.png" class="img-fluid" alt=""><span>Dịch vụ khác</span></div>
							   						<div class="txt-col">
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   							<div class="item-txt">
							   								<h6>8:45 Thứ Bảy tại Paris, Pháp: Paris Place d’Italie</h6>
								   							<p>Điểm gặp: McDonalds Restaurant</p>
								   							<p>Địa chỉ: 211 Boulevard Vincent Auriol, 75013 Paris</p>
								   							<p>Metro: Line 5, 6 & 7</p>
								   							<p>Stop: Place d’Italie  Exit 3, Vincent Auriol</p>
							   							</div>
							   						</div>
							   					</div>
							   				</div>
							   			</div>
							   		</div>
							   	</div>
							</div>
						</div>
						<div class="box-scroll pb-50" id="tour-4">
							<div class="title-src">Hình ảnh khách đi tour <a title="" href="javascript:0"><img src="images/close.png" class="img-fluid" alt=""></a></div>
							<div class="slide-gall slide-page hide-scr">
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-1.png" data-fancybox="group-1"><img src="images/gall-1.png" class="img-fluid w-100" alt=""></a></div>
								</div>
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-2.png" data-fancybox="group-1"><img src="images/gall-2.png" class="img-fluid w-100" alt=""></a></div>
								</div>
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-3.png" data-fancybox="group-1"><img src="images/gall-3.png" class="img-fluid w-100" alt=""></a></div>
								</div>
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-4.png" data-fancybox="group-1"><img src="images/gall-4.png" class="img-fluid w-100" alt=""></a></div>
								</div>
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-3.png" data-fancybox="group-1"><img src="images/gall-3.png" class="img-fluid w-100" alt=""></a></div>
								</div>
								<div class="item-slide">
									<div class="item-gall"><a title="" href="images/gall-2.png" data-fancybox="group-1"><img src="images/gall-2.png" class="img-fluid w-100" alt=""></a></div>
								</div>
							</div>
						</div>
						<div class="box-scroll pb-50" id="tour-5">
							<div class="title-src">Tour liên quan</div>
							<div class="slide-tour slide-page">
								<div class="item-slide">
									<div class="item-tour">
										<div class="avarta"><a title="" href=""><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info">
											<h3><a title="" href="">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
											<ul>
												<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
												<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
												<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
											</ul>
											<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
										</div>
									</div>
								</div>
								<div class="item-slide">
									<div class="item-tour">
										<div class="avarta"><a title="" href=""><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info">
											<h3><a title="" href="">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
											<ul>
												<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
												<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
												<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
											</ul>
											<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
										</div>
									</div>
								</div>
								<div class="item-slide">
									<div class="item-tour">
										<div class="avarta"><a title="" href=""><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info">
											<h3><a title="" href="">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
											<ul>
												<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
												<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
												<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
											</ul>
											<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
										</div>
									</div>
								</div>
								<div class="item-slide">
									<div class="item-tour">
										<div class="avarta"><a title="" href=""><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info">
											<h3><a title="" href="">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
											<ul>
												<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
												<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
												<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
											</ul>
											<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
										</div>
									</div>
								</div>
								<div class="item-slide">
									<div class="item-tour">
										<div class="avarta"><a title="" href=""><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info">
											<h3><a title="" href="">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
											<ul>
												<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
												<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
												<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
											</ul>
											<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>