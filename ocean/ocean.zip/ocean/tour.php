<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="avarta-bread"><img src="images/bread.png" class="img-fluid w-100" alt=""></div>
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Tour trong nước</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section class="box-tour pt-30 pb-50">
		<div class="container">
			<div class="list-tour">
				<h1 class="text-uppercase text-center title-pages">Tour trong nước</h1>
				<div class="table-info pb-50">
					<div class="table-responsive">
				        <table class="table table-bordered table-hover">
				          <thead>
				            <tr>
				            	<th class="text-center">Tên tour</th>
				            	<th class="text-center">Số ngày</th>
				            	<th class="text-center">Khách sạn</th>
				            	<th class="text-center">Phương tiện</th>
				            	<th class="text-center">Ngày khởi hành</th>
				            	<th class="text-center">Giá tour</th>
				            	<th class="text-center"></th>
				            </tr>
				          </thead>
				          <tbody>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				            <tr>
				            	<td>Buôn Mê Thuột - Gia Lai - Kon Tum - Măng Đen (3N3Đ)</td>
				            	<td>3N2Đ</td>
				            	<td>3*</td>
				            	<td>Xe du lịch</td>
				            	<td>22 / 01 / 2020</td>
				            	<td>2.100.000đ</td>
				            	<td><a title="" href="tour-detail.php">Chi tiết</a></td>
				            </tr>
				          </tbody>
				        </table>
				    </div>
				    <div class="load-more text-right"><a title="" href="">Trang sau<i class="fa fa-chevron-circle-right"></i></a></div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-4 col-6">
						<div class="item-tour">
							<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
								<ul>
									<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
									<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
									<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
								</ul>
								<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
							</div>
						</div>
					</div>
					<div class="pagination w-100">
						<ul class="list-inline w-100 text-center">
							<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-left"></i></a></li>
							<li class="list-inline-item"><a title="" href="" class="active">1</a></li>
							<li class="list-inline-item"><a title="" href="">2</a></li>
							<li class="list-inline-item"><a title="" href="">3</a></li>
							<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-right"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>