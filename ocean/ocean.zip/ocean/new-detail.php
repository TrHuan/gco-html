<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="service.php">Tin tức</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Chi tiết tin tức</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="service" class="pt-50 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="detail">
						<div class="title-new-detail">
							<h1>Nhà thờ St. Stephen và những ô cửa sổ rực rỡ của Marc Chagall</h1>
							<div class="date">20/03/2020</div>
							<div class="desc">
								Nhà thờ St. Stephen là nơi duy nhất ở Đức bạn có thể chiêm ngưỡng những ô cửa sổ rực rỡ của Marc Chagall. Ngoài ra, hãy tận hưởng muôn vàn chi tiết độc đáo trong nhà thờ mà các công trình kiến trúc phương Đông không bao giờ có được.
							</div>
						</div>
						<div class="content-detail">
							<p><img src="images/detail-2.png" alt=""></p>
							<p>Vào năm 990, Willigis, Tổng Giám mục Mainz và Tổng Giám mục của Đế chế La Mã đã quyết định xây dựng nhà thờ như một nơi cầu nguyện của Đế chế Hoàng đế. Vương cung thánh đường này được xây dựng theo phong cách Ottonian-tiền La Mã.</p>
							<p>Tuy nhiên vào năm 1290, công trình cũ này đã được thay thế bằng một tòa nhà theo kiến trúc Gothic. Đến thế kỉ 14, nhà thờ lại tiếp tục được sửa đổi, bổ sung. Cụ thể tu viện đã được thêm vào ở phía Nam nhà thờ trong giai đoạn 1462 – 1499, các chi tiết mang đậm dấu ấn baroque cũng được bổ sung.</p>
							<p>Vào năm 1877, khi tháp Powder bị phá hủy, nhà thờ St. Stephen cũng bị tàn phá nặng nề. Trong quá trình tái thiết, các chi tiết trang trí baroque đã được gỡ bỏ.</p>
							<p>Trong chiến tranh Thế giới thứ 2 St. Stephen tiếp tục thiệt hại nặng nề. Nhà thờ đã được xây dựng lại từ năm 1968 đến 1971. Phần vòm bị loại bỏ, thay thế vào đó là các trần gỗ phẳng.</p>
							<p>Có khoảng 200,000 khách du lịch Châu Âu ghé thăm nhà thờ mỗi năm. Đây là bằng chứng xác thực nhất thể hiện sự hấp dẫn của điểm đến này.</p>
							<p><img src="images/detail-2.png" alt=""></p>
							<p>Vào năm 990, Willigis, Tổng Giám mục Mainz và Tổng Giám mục của Đế chế La Mã đã quyết định xây dựng nhà thờ như một nơi cầu nguyện của Đế chế Hoàng đế. Vương cung thánh đường này được xây dựng theo phong cách Ottonian-tiền La Mã.</p>
							<p>Tuy nhiên vào năm 1290, công trình cũ này đã được thay thế bằng một tòa nhà theo kiến trúc Gothic. Đến thế kỉ 14, nhà thờ lại tiếp tục được sửa đổi, bổ sung. Cụ thể tu viện đã được thêm vào ở phía Nam nhà thờ trong giai đoạn 1462 – 1499, các chi tiết mang đậm dấu ấn baroque cũng được bổ sung.</p>
							<p>Vào năm 1877, khi tháp Powder bị phá hủy, nhà thờ St. Stephen cũng bị tàn phá nặng nề. Trong quá trình tái thiết, các chi tiết trang trí baroque đã được gỡ bỏ.</p>
							<p>Trong chiến tranh Thế giới thứ 2 St. Stephen tiếp tục thiệt hại nặng nề. Nhà thờ đã được xây dựng lại từ năm 1968 đến 1971. Phần vòm bị loại bỏ, thay thế vào đó là các trần gỗ phẳng.</p>
							<div class="like-share pt-30 pb-30">
								<ul class="list-inline">
									<li class="list-inline-item"><a title="" href=""><img src="images/like.png" class="img-fluid" alt=""></a></li>	
								</ul>
							</div>
							<div class="comment">
								<img src="images/cmt.png" class="img-fluid" alt="">
							</div>
						</div>
					</div>
					<div class="other pt-50">
						<div class="title"><h2 class="text-uppercase">Bài viết liên quan</h2></div>
						<div class="other-news slide-page">
							<div class="item-slide">
								<div class="item-new-other">
									<div class="avarta"><a title="" href=""><img src="images/n-ot-1.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info">
										<div class="date">20/03/2020</div>
										<h4><a title="" href="">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h4>
									</div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-new-other">
									<div class="avarta"><a title="" href=""><img src="images/n-ot-2.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info">
										<div class="date">20/03/2020</div>
										<h4><a title="" href="">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h4>
									</div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-new-other">
									<div class="avarta"><a title="" href=""><img src="images/n-ot-1.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info">
										<div class="date">20/03/2020</div>
										<h4><a title="" href="">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h4>
									</div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-new-other">
									<div class="avarta"><a title="" href=""><img src="images/n-ot-2.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info">
										<div class="date">20/03/2020</div>
										<h4><a title="" href="">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="side-bar">
						<div class="title text-center"><h2 class="text-uppercase justify-content-center">tour mới nhất</h2></div>
						<div class="tour-news">
							<div class="item-tour-hot" style="margin-bottom: 30px;">
								<div class="avarta">
									<a title="" href="tour-detail.php"><img src="images/t-1.png" class="img-fluid w-100" alt=""></a>
									<div class="date-time">
										<ul class="d-flex w-100 justify-content-between">
											<li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
											<li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
										</ul>
									</div>
								</div>
								<div class="info">
									<h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
									<ul>
										<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
										<li class="font-weight-bold"><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
									</ul>
									<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
								</div>
							</div>
							<div class="item-tour-hot" style="margin-bottom: 30px;">
								<div class="avarta">
									<a title="" href="tour-detail.php"><img src="images/t-3.png" class="img-fluid w-100" alt=""></a>
									<div class="date-time">
										<ul class="d-flex w-100 justify-content-between">
											<li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
											<li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
										</ul>
									</div>
								</div>
								<div class="info">
									<h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
									<ul>
										<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
										<li class="font-weight-bold"><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
									</ul>
									<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
								</div>
							</div>
							<div class="item-tour-hot" style="margin-bottom: 30px;">
								<div class="avarta">
									<a title="" href="tour-detail.php"><img src="images/t-2.png" class="img-fluid w-100" alt=""></a>
									<div class="date-time">
										<ul class="d-flex w-100 justify-content-between">
											<li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
											<li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
										</ul>
									</div>
								</div>
								<div class="info">
									<h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
									<ul>
										<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
										<li class="font-weight-bold"><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
									</ul>
									<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>