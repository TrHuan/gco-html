$(document).ready(function() {
    if ($('.back-top').length) {
        var scrollTrigger = 300,
            backToTop = function () {
                var scrollTop = $(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    $('.back-top').addClass('show');

                } else {
                    $('.back-top').removeClass('show');
                }
            };
        backToTop();
        $(window).on('scroll', function () {
            backToTop();
        });

        $('.back-top').on('click', function (e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 700);
        });
    }
})

$(window).scroll(function(){
    if ($(window).scrollTop() >= 50) {
        $('.header-menu').addClass('fixed-header');
        $('main').addClass('visible-title');
    }
    else {
        $('.header-menu').removeClass('fixed-header');
        $('main').removeClass('visible-title');
    }
});

// $(window).scroll(function(){
//     if ($(window).scrollTop() >= 34) {
//         $('.menu-mobile').addClass('fixed-header');
//         $('main').addClass('visible-title');
//     }
//     else {
//         $('.menu-mobile').removeClass('fixed-header');
//         $('main').removeClass('visible-title');
//     }
// });

if($(window).innerWidth() <= 1024){
    $(window).scroll(function(){
        if ($(window).scrollTop() >= 34) {
            $('.menu-mobile').addClass('fixed-header');
            $('main').addClass('visible-title');
        }
        else {
            $('.menu-mobile').removeClass('fixed-header');
            $('main').removeClass('visible-title');
        }
    });
}

var dropdowns = $(".dropdown");
dropdowns.find("dt").click(function(){
    dropdowns.find("dd ul.drop-tg").hide();
    $(this).next().children().toggle();
});
dropdowns.find("dd ul.drop-tg li a").click(function(){
    var leSpan = $(this).parents(".dropdown").find("dt a span");
    $(this).parents(".dropdown").find('dd a').each(function(){
    $(this).removeClass('selected');
  });
    leSpan.html($(this).html());
    if($(this).hasClass('default')){
    leSpan.removeClass('selected')
  }
    else{
        leSpan.addClass('selected');
        $(this).addClass('selected');
    }
    $(this).parents("ul.drop-tg").hide();
});
$(document).bind('click', function(e){
    if (! $(e.target).parents().hasClass("dropdown")) $(".dropdown dd ul.drop-tg").hide();
});

$('.slide-banner').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 1,
    slidesToScroll: 1, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
});

$('.slide-feed').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 1,
    slidesToScroll: 1, 
    prevArrow: '',
    nextArrow: '',
});

$('.slide-srv').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 6,
    slidesToScroll: 1, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-sale').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-gall').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 4,
    slidesToScroll: 2, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-tour').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 4,
    slidesToScroll: 1, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-part').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 6,
    slidesToScroll: 2, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-other').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 2, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.other-news').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 2, 
    prevArrow: '<button class="prev"><i class="fa fa-chevron-left"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-chevron-right"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});

$('.slide-video').slick({
    autoplay: true,
    arrow: true,
    dots: false,
    slidesToShow: 4,
    slidesToScroll: 1, 
    vertical: true,
    prevArrow: '<button class="prev"><i class="fa fa-long-arrow-down"></i></button>',
    nextArrow: '<button class="next"><i class="fa fa-long-arrow-up"></i></button>',
    responsive: [
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }
    ]
});


$('.slider-for').slick({
    autoplay: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    asNavFor: '.slider-nav',
});
$('.slider-nav').slick({
    autoplay:false,
    arrow:false,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1
            }
        }
    ],
    asNavFor: '.slider-for',
    dots: false,
    focusOnSelect: true,
    prevArrow: '', 
    nextArrow: '', 
});


$(document).ready(function(){
    $('.item-video').click(function(){
        var tab_id = $(this).attr('data-tab');
        $('.item-video').removeClass('active');
        $('.tabs-video').removeClass('active');
        $(this).addClass('active');
        $("#"+tab_id).addClass('active');
    })

    $(".title-src a").click(function() {    
      $(this).parents().children('.hide-scr').slideToggle(400);
    });
})

$('.clc-src a').click(function(e){
  e.preventDefault();
  var target = $($(this).attr('href'));
  if($(window).innerWidth() >= 768){
    if(target.length){
        var scrollTo = target.offset().top - 140;
        $('body, html').animate({scrollTop: scrollTo+'px'}, 800);
      }
  }
  else {
    if(target.length){
        var scrollTo = target.offset().top - 70;
        $('body, html').animate({scrollTop: scrollTo+'px'}, 800);
      }
  }
  $('.clc-src a').removeClass("active");
  $(this).addClass("active");
});

(function($){
    $(document).ready(function(){
    $('.lightbox').fancybox();
    });
})(jQuery)

jQuery(document).ready(function( $ ) {
  $("#menu").mmenu({
     "extensions": [
        "fx-menu-zoom"
     ],
     "counters": true
  });
});


$(function () {
    $('.input-group.date-birth').datetimepicker({
        maxDate: moment().add(0,'days'),
        format: 'DD-MM-YYYY'
    });
});

$(function () {
    $('.input-group.date-book').datetimepicker({
        minDate: moment().add(1),
        format: 'DD-MM-YYYY'
    });
});


function getTimeRemaining(endtime) {
  var t = Date.parse(endtime) - Date.parse(new Date());
  var seconds = Math.floor((t / 1000) % 60);
  var minutes = Math.floor((t / 1000 / 60) % 60);
  var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
  var days = Math.floor(t / (1000 * 60 * 60 * 24));
  return {
    'total': t,
    'days': days,
    'hours': hours,
    'minutes': minutes,
    'seconds': seconds
  };
}

function initializeClock(id, endtime) {
  var clock = document.getElementById(id);
  var daysSpan = clock.querySelector('.days');
  var hoursSpan = clock.querySelector('.hours');
  var minutesSpan = clock.querySelector('.minutes');
  var secondsSpan = clock.querySelector('.seconds');

  function updateClock() {
    var t = getTimeRemaining(endtime);

    daysSpan.innerHTML = t.days;
    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

    if (t.total <= 0) {
      clearInterval(timeinterval);
    }
  }

updateClock();
  var timeinterval = setInterval(updateClock, 1000);
}

var deadline = new Date(Date.parse(new Date()) + 8 * 60 + 9 * 60 * 1000);
initializeClock('clockdiv-end-1', deadline);

var deadline = new Date(Date.parse(new Date()) + 8 * 60 + 15 * 60 * 1000);
initializeClock('clockdiv-end-2', deadline);

var deadline = new Date(Date.parse(new Date()) + 8 * 60 + 90 * 60 * 1000);
initializeClock('clockdiv-end-3', deadline);

var deadline = new Date(Date.parse(new Date()) + 8 * 60 + 16 * 60 * 1000);
initializeClock('clockdiv-end-4', deadline);