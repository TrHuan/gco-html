<?php include 'header.php';?>
<style>
	header, footer {
		display: none;
	}
</style>
<main>
	<section id="error">
		<div class="container">
			<div class="content-err text-center">
				<div class="logo"><a href="index.php"><img src="images/logo-light.png" class="img-fluid" alt=""></a></div>
				<div class="img-er"><img src="images/404.png" class="img-fluid" alt=""></div>
				<h1>Không tìm thấy trang</h1>
				<p>Trang đã bị xóa hoặc địa chỉ URL không đúng</p>
				<div class="go-home"><a href="index.php">Quay về trang chủ</a></div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>