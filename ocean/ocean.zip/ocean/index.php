<?php include 'header.php';?>
<main>
	<section id="banner">
		<div class="container">
			<div class="slide-banner">
				<div class="item"><a title="" href=""><img src="images/banner.png" class="img-fluid w-100" alt=""></a></div>
				<div class="item"><a title="" href=""><img src="images/banner.png" class="img-fluid w-100" alt=""></a></div>
				<div class="item"><a title="" href=""><img src="images/banner.png" class="img-fluid w-100" alt=""></a></div>
			</div>
			<div class="box-search">
				<div class="row">
					<div class="col-md-3">
						<div class="item">
							<label><img src="images/search-1.png" class="img-fluid" alt="">Nơi khởi hành</label>
							<input type="text" placeholder="Nhập nơi khởi hành ...">
						</div>
					</div>
					<div class="col-md-3">
						<div class="item">
							<label><img src="images/search-2.png" class="img-fluid" alt="">Điểm đến</label>
							<input type="text" placeholder="Nhập nơi đến ...">
						</div>
					</div>
					<div class="col-md-3">
						<div class="item">
							<label><img src="images/search-3.png" class="img-fluid" alt="">Ngày khởi hành</label>
							<!-- <input type="text" placeholder="Ngày / tháng / năm" class="inp_date">  -->
							<div class="form-group">
						        <div class='input-group date date-book' id='datetimepicker2'>
						        	<input type='text' placeholder="Ngày / tháng / năm" class="inp_date" />
						        	<span class="input-group-addon"></span>
						        </div>
						    </div>
						</div> 
					</div>
					<div class="col-md-3">
						<div class="item">
							<button type="submit" class="text-uppercase btn-search">Tìm kiếm</button>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</section>
	<section class="box-srv pt-50 pb-50">
		<div class="container">
			<div class="slide-srv slide-page">
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-1.png" class="img-fluid" alt=""></span><span>Tour giỗ tổ</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-2.png" class="img-fluid" alt=""></span><span>Tour lễ 30/4</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-3.png" class="img-fluid" alt=""></span><span>Tour lễ 2/9</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-4.png" class="img-fluid" alt=""></span><span>Hè sôi động</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-5.png" class="img-fluid" alt=""></span><span>Tour biển đảo</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-6.png" class="img-fluid" alt=""></span><span>Xứ sở Chùa Vàng</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-1.png" class="img-fluid" alt=""></span><span>Hè sôi động</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-2.png" class="img-fluid" alt=""></span><span>Tour biển đảo</span></a></div>
				<div class="item item-slide"><a title="" href="tour.php"><span class="icon"><img src="images/sv-3.png" class="img-fluid" alt=""></span><span>Xứ sở Chùa Vàng</span></a></div>
			</div>
		</div>
	</section>
	<section class="box-tour pb-50">
		<div class="container">
			<div class="title"><h2><img src="images/title-1.png" class="img-fluid" alt="">Tour giờ chót</h2></div>
			<div class="slide-sale slide-page">
				<div class="item-slide">
					<div class="item-tour-hot">
						<div class="avarta">
							<a title="" href="tour-detail.php"><img src="images/t-1.png" class="img-fluid w-100" alt=""></a>
							<div id="clockdiv-end-1" class="clockdiv">
		              			<ul class="list-inline">	
		              				<li class="list-inline-item"><span class="days"></span> <span>Ngày</span></li>
		              				<li class="list-inline-item"><span class="hours"></span><label>:</label></li>
		              				<li class="list-inline-item"><span class="minutes"></span><label>:</label></li>
		              				<li class="list-inline-item"><span class="seconds"></span></li>
		              			</ul>
							</div>
							<div class="date-time">
								<ul class="d-flex w-100 justify-content-between">
									<li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
									<li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
								</ul>
							</div>
						</div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
							<ul>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li class="font-weight-bold flex-center-bettwen">
                                    <span><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></span>
                                    <div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
                                </li>
							</ul>
						</div>
					</div>
				</div>
                <div class="item-slide">
                    <div class="item-tour-hot">
                        <div class="avarta">
                            <a title="" href="tour-detail.php"><img src="images/t-2.png" class="img-fluid w-100" alt=""></a>
                            <div id="clockdiv-end-2" class="clockdiv">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><span class="days"></span> <span>Ngày</span></li>
                                    <li class="list-inline-item"><span class="hours"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="minutes"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="seconds"></span></li>
                                </ul>
                            </div>
                            <div class="date-time">
                                <ul class="d-flex w-100 justify-content-between">
                                    <li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
                                    <li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="info">
                            <h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
                            <ul>
                                <li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
                                <li class="font-weight-bold flex-center-bettwen">
                                    <span><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></span>
                                    <div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="item-slide">
                    <div class="item-tour-hot">
                        <div class="avarta">
                            <a title="" href="tour-detail.php"><img src="images/t-1.png" class="img-fluid w-100" alt=""></a>
                            <div id="clockdiv-end-3" class="clockdiv">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><span class="days"></span> <span>Ngày</span></li>
                                    <li class="list-inline-item"><span class="hours"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="minutes"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="seconds"></span></li>
                                </ul>
                            </div>
                            <div class="date-time">
                                <ul class="d-flex w-100 justify-content-between">
                                    <li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
                                    <li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="info">
                            <h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
                            <ul>
                                <li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
                                <li class="font-weight-bold flex-center-bettwen">
                                    <span><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></span>
                                    <div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="item-slide">
                    <div class="item-tour-hot">
                        <div class="avarta">
                            <a title="" href="tour-detail.php"><img src="images/t-2.png" class="img-fluid w-100" alt=""></a>
                            <div id="clockdiv-end-4" class="clockdiv">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><span class="days"></span> <span>Ngày</span></li>
                                    <li class="list-inline-item"><span class="hours"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="minutes"></span><label>:</label></li>
                                    <li class="list-inline-item"><span class="seconds"></span></li>
                                </ul>
                            </div>
                            <div class="date-time">
                                <ul class="d-flex w-100 justify-content-between">
                                    <li><img src="images/ic-1.png" class="img-fluid" alt=""><span>22/06/2020 - 7 ngày</span></li>
                                    <li><img src="images/ic-2.png" class="img-fluid" alt=""><span>5 chỗ</span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="info">
                            <h3><a title="" href="tour-detail.php">Đà Nẵng - Bà Nà - Cầu Vàng</a></h3>
                            <ul>
                                <li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
                                <li class="font-weight-bold flex-center-bettwen">
                                    <span><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></span>
                                    <div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
			</div>
			<div class="load-more text-center"><a title="" href="tour.php">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div>
		</div>
	</section>
	<section class="tour-hot">
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-md-5">
					<div class="hot-left ml-auto">
						<h1><a title="" href="tour-detail.php">Tour Phú Quốc <br>Chỉ 3.200.000đ trọn gói  3N2Đ</a></h1>
						<div class="desc">
							Sỡ hữu ngay mùa hè trọn vẹn với gia đình tại Đảo Ngọc Phú Quốc. Chỉ với 3.200.000đ bạn có ngay trải nghiệm tại hòn đảo xinh đẹp. Giá vé đã bao gồm vé máy bay khứ hồi, 2 bữa sáng buffet, 4 bữa ăn chính + tặng vé lặn ngắm san hô miễn phí...
						</div>
						<div class="btn-book"><a title="" href="tour-detail.php">Đặt Tour <i class="fa fa-arrow-right"></i></a></div>
					</div>
				</div>
				<div class="col-md-7">
					<img src="images/t-hot.png" class="img-fluid w-100" alt="">
				</div>
			</div>
		</div>
	</section>
	<section class="box-tour pt-50">
		<div class="container">
			<div class="title"><h2><img src="images/title2.png" class="img-fluid" alt="">Tour trong nước</h2></div>
			<div class="slide-tour slide-page">
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li class="flex-center-bettwen">
                                    <i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span>
                                </li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
			</div>
			<div class="load-more text-center pt-30"><a title="" href="tour.php">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div>
		</div>
	</section>
	<section class="box-tour pt-50 pb-50">
		<div class="container">
			<div class="title"><h2><img src="images/title3.png" class="img-fluid" alt="">Tour nước ngoài</h2></div>
			<div class="slide-tour slide-page">
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-2.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
				<div class="item-slide">
					<div class="item-tour">
						<div class="avarta"><a title="" href="tour-detail.php"><img src="images/tour-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<h3><a title="" href="tour-detail.php">Maldives - Tặng 1 đêm trải nghiệm đẳng cấp…</a></h3>
							<ul>
								<li class="d-flex justify-content-between"><span><i class="fa fa-calendar"></i> 5 ngày 4 đêm</span><span><img src="images/vote.png" class="img-fluid" alt=""></span></li>
								<li><i class="fa fa-map-marker"></i>Nơi khởi hành: Hà Nội</li>
								<li><i class="fa fa-tags"></i><del>25.500.000đ</del><span class="price">18.552.000đ</span></li>
							</ul>
							<div class="btn-more"><a title="" href="book-tour.php"><i class="fa fa-shopping-cart"></i>Đặt Tour</a></div>
						</div>
					</div>
				</div>
			</div>
			<div class="load-more text-center pt-30"><a title="" href="">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div>
		</div>
	</section>
	<section class="feed-back pb-50">
		<div class="container">
			<div class="title">
				<div class="row align-items-center">
					<div class="col-md-8 col-sm-8 col-8"><h2><img src="images/title4.png" class="img-fluid" alt="">Phản hồi của khách hàng</h2></div>
					<div class="col-md-4 col-sm-4 col-4"><div class="load-more text-right"><a title="" href="news.php">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div></div>
				</div>
			</div>
			<div class="feed-top">
				<div class="row">
					<div class="col-md-6">
						<div class="slide-feed">
							<div class="item">
								<div class="desc">
									“ Chúc team Ocean tourism luôn nhiều sức khoẻ và đầy nhiệt huyết trên con đường đã chọn nhé! Cảm ơn Ocean tourism đã cho team mình 1 kì nghỉ vui và ấn tượng! Cảm ơn anh Ty, Phương và Phượng, sự nhiệt tình và đáng iu của các anh chị làm tụi em quên cả nỗi sợ say xe luôn á! Chúc các anh chị luôn thành công nhé! Nếu có dịp đi chơi nhất định sẽ đặt tour của các anh chị á! ”
								</div>
								<div class="info">
									<h5>Chị Trà Nguyễn</h5>
									<span>20/06/2020</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="list-feed">
				<div class="row">
					<div class="col-md-6">
						<div class="item">
							<div class="info">
								<div class="desc">
									“ Chúc team Ocean tourism luôn nhiều sức khoẻ và đầy nhiệt huyết trên con đường đã chọn nhé! Cảm ơn Ocean tourism đã cho team mình 1 kì nghỉ vui và ấn tượng! Cảm ơn anh! ”
								</div>
								<div class="per">
									<h5>Chị Trà Nguyễn</h5>
									<span>20/06/2020</span>
								</div>
							</div>
							<div class="avarta">
								<img src="images/f-1.png" class="img-fluid w-100" alt="">
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="item">
							<div class="info">
								<div class="desc">
									“ Chúc team Ocean tourism luôn nhiều sức khoẻ và đầy nhiệt huyết trên con đường đã chọn nhé! Cảm ơn Ocean tourism đã cho team mình 1 kì nghỉ vui và ấn tượng! Cảm ơn anh! ”
								</div>
								<div class="per">
									<h5>Chị Trà Nguyễn</h5>
									<span>20/06/2020</span>
								</div>
							</div>
							<div class="avarta">
								<img src="images/f-2.png" class="img-fluid w-100" alt="">
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="item">
							<div class="info">
								<div class="desc">
									“ Chúc team Ocean tourism luôn nhiều sức khoẻ và đầy nhiệt huyết trên con đường đã chọn nhé! Cảm ơn Ocean tourism đã cho team mình 1 kì nghỉ vui và ấn tượng! Cảm ơn anh! ”
								</div>
								<div class="per">
									<h5>Chị Trà Nguyễn</h5>
									<span>20/06/2020</span>
								</div>
							</div>
							<div class="avarta">
								<img src="images/f-2.png" class="img-fluid w-100" alt="">
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="item">
							<div class="info">
								<div class="desc">
									“ Chúc team Ocean tourism luôn nhiều sức khoẻ và đầy nhiệt huyết trên con đường đã chọn nhé! Cảm ơn Ocean tourism đã cho team mình 1 kì nghỉ vui và ấn tượng! Cảm ơn anh! ”
								</div>
								<div class="per">
									<h5>Chị Trà Nguyễn</h5>
									<span>20/06/2020</span>
								</div>
							</div>
							<div class="avarta">
								<img src="images/f-1.png" class="img-fluid w-100" alt="">
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<section class="box-news pb-50">
		<div class="container">
			<div class="title">
				<div class="row align-items-center">
					<div class="col-md-8 col-sm-8 col-8"><h2><img src="images/title-5.png" class="img-fluid" alt="">Tin tức</h2></div>
					<div class="col-md-4 col-sm-4 col-4"><div class="load-more text-right"><a title="" href="news.php">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div></div>
				</div>
			</div>
			<div class="list-box-news">
				<div class="row">
					<div class="col-md-6">
						<div class="news-bigs">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/n-bigs.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h2><a title="" href="new-detail.php">Sự tích về Miếu Bà Phi Yến và câu chuyện Hoàng Tử Cải bị ném xuống biển</a></h2>
								<div class="desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type ...</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="news-small">
							<div class="item">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/sm-1.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info">
									<h3><a title="" href="new-detail.php">10 điều khiến khách tây ngạc  nhiên</a></h3>
									<label>14:30  06/08/2020</label>
									<div class="desc">
										Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
									</div>
								</div>
							</div>
							<div class="item">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/sm-2.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info">
									<h3><a title="" href="new-detail.php">10 điều khiến khách tây ngạc  nhiên</a></h3>
									<label>14:30  06/08/2020</label>
									<div class="desc">
										Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
									</div>
								</div>
							</div>
							<div class="item">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/sm-3.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info">
									<h3><a title="" href="new-detail.php">10 điều khiến khách tây ngạc  nhiên</a></h3>
									<label>14:30  06/08/2020</label>
									<div class="desc">
										Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="box-blog pb-50">
		<div class="container">
			<div class="title">
				<div class="row align-items-center">
					<div class="col-md-8 col-sm-8 col-8"><h2><img src="images/title-6.png" class="img-fluid" alt="">Blog du lịch</h2></div>
					<div class="col-md-4 col-sm-4 col-4"><div class="load-more text-right"><a title="" href="news.php">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div></div>
				</div>
			</div>
			<div class="list-blog">
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<div class="big">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h2><a title="" href="new-detail.php">Những địa điểm du lịch ở Phú Yên</a></h2>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="big">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h2><a title="" href="new-detail.php">8 lý do nhất định phải đến Ghềnh Đá Đĩa Phú Yên bằng “ mọi giá”</a></h2>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="bg-small">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-3.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
								<div class="desc">
									Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="bg-small">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-4.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
								<div class="desc">
									Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="bg-small">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-4.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
								<div class="desc">
									Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="bg-small">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/b-3.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
								<div class="desc">
									Matthew Pike cho rằng khách Tây học hỏi một số điều ở Việt Nam - đất nước hơn 90 triệu dân [...]
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="box-video pb-50">
		<div class="container">
			<div class="title">
				<div class="row align-items-center">
					<div class="col-md-8 col-sm-8 col-8"><h2><img src="images/title-7.png" class="img-fluid" alt="">Video</h2></div>
					<div class="col-md-4 col-sm-4 col-4"><div class="load-more text-right"><a title="" href="">Xem Thêm <i class="fa fa-chevron-circle-right"></i></a></div></div>
				</div>
			</div>
			<div class="list-video">
				<div class="row">
					<div class="col-md-8">
						<div class="video-big">
							<div class="tabs-video active" id="video-1">
								<iframe width="1109" height="436" src="https://www.youtube.com/embed/aztbvh4W8y0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>
							<div class="tabs-video" id="video-2">
								<iframe width="1019" height="573" src="https://www.youtube.com/embed/e1SHsU3f32w" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="slide-video">
							<div class="video-item-slide">
								<div class="item-video active" data-tab="video-1">
									<div class="avarta">
										<img src="images/vd-2.png" class="img-fluid w-100" alt="">
										<div class="play"><img src="images/play.png" class="img-fluid" alt=""></div>
										<div class="play-time">
											<img src="images/pause.png" class="img-fluid" alt=""><span>01:20</span>
										</div>
									</div>
									<div class="info">
										<h3><a title="" href="javascript:0">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
									</div>
								</div>
							</div>
							<div class="video-item-slide">
								<div class="item-video" data-tab="video-2">
									<div class="avarta">
										<img src="images/vd-3.png" class="img-fluid w-100" alt="">
										<div class="play"><img src="images/play.png" class="img-fluid" alt=""></div>
										<div class="play-time">
											<img src="images/pause.png" class="img-fluid" alt=""><span>01:20</span>
										</div>
									</div>
									<div class="info">
										<h3><a title="" href="javascript:0">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
									</div>
								</div>
							</div>
							<div class="video-item-slide">
								<div class="item-video" data-tab="video-1">
									<div class="avarta">
										<img src="images/vd-4.png" class="img-fluid w-100" alt="">
										<div class="play"><img src="images/play.png" class="img-fluid" alt=""></div>
										<div class="play-time">
											<img src="images/pause.png" class="img-fluid" alt=""><span>01:20</span>
										</div>
									</div>
									<div class="info">
										<h3><a title="" href="javascript:0">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
									</div>
								</div>
							</div>
							<div class="video-item-slide">
								<div class="item-video" data-tab="video-2">
									<div class="avarta">
										<img src="images/vd-3.png" class="img-fluid w-100" alt="">
										<div class="play"><img src="images/play.png" class="img-fluid" alt=""></div>
										<div class="play-time">
											<img src="images/pause.png" class="img-fluid" alt=""><span>01:20</span>
										</div>
									</div>
									<div class="info">
										<h3><a title="" href="javascript:0">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
									</div>
								</div>
							</div>
							<div class="video-item-slide">
								<div class="item-video" data-tab="video-1">
									<div class="avarta">
										<img src="images/vd-4.png" class="img-fluid w-100" alt="">
										<div class="play"><img src="images/play.png" class="img-fluid" alt=""></div>
										<div class="play-time">
											<img src="images/pause.png" class="img-fluid" alt=""><span>01:20</span>
										</div>
									</div>
									<div class="info">
										<h3><a title="" href="javascript:0">Những cột đá cao 70m tựa cảnh ngoài hành tinh</a></h3>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="box-partner pb-50">
		<div class="container">
			<div class="title">
				<h2><img src="images/title-8.png" class="img-fluid" alt="">Khách hàng của chúng tôi</h2>
			</div>
			<div class="slide-part slide-page text-center">
				<div class="item-slide"><a title="" href=""><img src="images/part-1.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-2.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-1.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-2.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-1.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-2.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-1.png" class="img-fluid" alt=""></a></div>
				<div class="item-slide"><a title="" href=""><img src="images/part-2.png" class="img-fluid" alt=""></a></div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>