<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="service.php">Dịch vụ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Chi tiết dịch vụ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="service" class="pt-50 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="detail">
						<div class="title-detail">
							<h1>Dịch vụ thuê vật dụng teambuilding</h1>
						</div>
						<div class="content-detail">
							<div class="row">
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-1.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Bóng bay</a></h3></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-2.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Cổng phao</a></h3></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-3.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Lều trại</a></h3></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-1.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Bóng bay</a></h3></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-2.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Cổng phao</a></h3></div>
									</div>
								</div>
								<div class="col-md-4 col-sm-4">
									<div class="item-service">
										<div class="avarta"><a title="" href=""><img src="images/thue-3.png" class="img-fluid w-100" alt=""></a></div>
										<div class="info text-center"><h3><a title="" href="javascript:0">Lều trại</a></h3></div>
									</div>
								</div>
							</div>
							<div class="box-price">
								<div class="title-baogia text-uppercase">Yêu cầu nhận báo giá tại đây</div>
								<div class="list-form">
									<div class="item">
										<label>Địa điểm tổ chức (*)</label>
										<input type="text" placeholder="Nhập thành phố, địa danh, khách sạn">
									</div>
									<div class="item">
										<label>Thời gian nhận vật dụng (*)</label>
										<!-- <input type="text" placeholder="Ngày, tháng, năm">  -->
										<div class="form-group w-100">
									        <div class='input-group date date-book' id='datetimepicker2'>
									        	<input type='text' placeholder="" class="inp_date" />
									        	<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									        </div>
									    </div>
									</div>
									<div class="item">
										<label>Họ tên người liên hệ (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Điện thoại (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Email (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Bạn cần thuê những <br>vật dụng nào? </label>
										<textarea name="" id="" cols="30" rows="10"></textarea>
									</div>
								</div>
								<div class="btn-form text-center">
									<input type="submit" value="Gửi ngay" class="btn-price">
								</div>
							</div>
						</div>
					</div>
					<div class="other pt-50">
						<div class="title"><h2>Dịch vụ liên quan</h2></div>
						<div class="slide-other slide-page">
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="side-bar sticky-top">
						<div class="box-info-srv">
							<div class="title-srv">Liên hệ tư vấn</div>
							<ul>
								<li style="padding-left: 25px;"><img src="images/p-1.png" class="img-fluid" alt="">Hotline: 028.62959568</li>
								<li style="padding-left: 25px;"><img src="images/p-2.png" class="img-fluid" alt="">Phone: 090145598</li>
							</ul>
						</div>
						<div class="box-info-srv">
							<div class="title-srv">Giờ làm việc</div>
							<ul>
								<li class="d-flex justify-content-between"><span>Thứ 2 - thứ 6</span><span>08:00 AM - 05:00 PM</span></li>
								<li class="d-flex justify-content-between" style="color: #b80000"><span>Thứ 7 - CN</span><span>Closed</span></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>