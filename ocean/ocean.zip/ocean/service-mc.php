<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="service.php">Dịch vụ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Chi tiết dịch vụ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="service" class="pt-50 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="detail">
						<div class="title-detail"><h1>Dịch vụ thuê MC - HDV</h1></div>
						<div class="content-detail">
							<div class="row">
								<div class="col-md-6">
									<p><img src="images/detail.png" alt=""></p>
								</div>
								<div class="col-md-6">
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only fiveries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
								</div>
								<div class="col-md-12">
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
									<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
								</div>
							</div>
							<div class="box-price">
								<div class="title-baogia text-uppercase">Yêu cầu nhận báo giá tại đây</div>
								<div class="list-form">
									<div class="item">
										<label>Số lượng (*)</label>
										<ul>
											<li style="flex: 0 0 50%">
												<select name="" id="" class="text-center">
													<option value="">Số lượng MC</option>
													<option value="">1</option>
													<option value="">2</option>
													<option value="">3</option>
												</select>
											</li>
											<li style="flex: 0 0 50%">
												<select name="" id="" class="text-center">
													<option value="">Số lượng HDV</option>
													<option value="">1</option>
													<option value="">2</option>
													<option value="">3</option>
												</select>
											</li>
										</ul>
									</div>
									<div class="item">
										<label>Giới tính (*)</label>
										<input type="text" placeholder="3 nam, 2 nữ">
									</div>
									<div class="item">
										<label>Độ tuổi (*)</label>
										<input type="text" placeholder="Từ 20 - 25 tuổi">
									</div>
									<div class="item">
										<label>Địa điểm (*)</label>
										<input type="text" placeholder="Nhập thành phố, địa danh, khách sạn">
									</div>
									<div class="item">
										<label>Hành trình từ:</label>
										<input type="text" placeholder="Nhập thành phố, địa danh, khách sạn">
									</div>
									<div class="item">
										<label>Hành trình đến:</label>
										<input type="text" placeholder="Nhập thành phố, địa danh, khách sạn">
									</div>
									<div class="item">
										<label>Ngày đi (*)</label>
										<!-- <input type="text" placeholder="Ngày, tháng, năm"> -->
										<div class="form-group w-100">
									        <div class='input-group date date-book' id='datetimepicker2'>
									        	<input type='text' placeholder="" class="inp_date" />
									        	<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									        </div>
									    </div>
									</div>
									<div class="item">
										<label>Ngày về (*)</label>
										<!-- <input type="text" placeholder="Ngày, tháng, năm"> -->
										<div class="form-group w-100">
									        <div class='input-group date date-book' id='datetimepicker2'>
									        	<input type='text' placeholder="" class="inp_date" />
									        	<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									        </div>
									    </div>
									</div>
									<div class="item">
										<label>Họ tên liên hệ (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Điện thoại (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Email (*)</label>
										<input type="text" placeholder="">
									</div>
									<div class="item">
										<label>Yêu cầu khác </label>
										<textarea name="" id="" cols="30" rows="10"></textarea>
									</div>
								</div>
								<div class="btn-form text-center">
									<input type="submit" value="Gửi ngay" class="btn-price">
								</div>
							</div>
						</div>
					</div>
					<div class="other pt-50">
						<div class="title"><h2>Dịch vụ liên quan</h2></div>
						<div class="slide-other slide-page">
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
							<div class="item-slide">
								<div class="item-service">
									<div class="avarta"><a title="" href=""><img src="images/other.png" class="img-fluid w-100" alt=""></a></div>
									<div class="info text-center"><h3><a title="" href="">Đặt phòng khách sạn</a></h3></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="side-bar sticky-top">
						<div class="box-info-srv">
							<div class="title-srv">Liên hệ tư vấn</div>
							<ul>
								<li style="padding-left: 25px;"><img src="images/p-1.png" class="img-fluid" alt="">Hotline: 028.62959568</li>
								<li style="padding-left: 25px;"><img src="images/p-2.png" class="img-fluid" alt="">Phone: 090145598</li>
							</ul>
						</div>
						<div class="box-info-srv">
							<div class="title-srv">Giờ làm việc</div>
							<ul>
								<li class="d-flex justify-content-between"><span>Thứ 2 - thứ 6</span><span>08:00 AM - 05:00 PM</span></li>
								<li class="d-flex justify-content-between" style="color: #b80000"><span>Thứ 7 - CN</span><span>Closed</span></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>