<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<!-- <div class="avarta-bread"><img src="images/bread-2.png" class="img-fluid w-100" alt=""></div>  -->
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="tour.php">Tour trong nước</a></li>
					<li class="list-inline-item"><a title="" href="tour-detail.php">Chi tiết Tour trong nước</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Đặt tour</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="tour-detail" class="pt-50 pb-50">
		<div class="container">
			<div class="content">
				<h1 class="title-tour text-center">Hoàn tất đặt tour</h1>
                <h4 class="bookh">MÃ BOOKING: BK_SGVP3N2Đ</h4>
				<div class="info-book">
					<h3>Thông tin cơ bản tour</h3>
					<div class="row">
						<div class="col-md-6">
							<div class="txt-tour">
								<ul>
									<li><p>Tên tour:</p><span> SÀI GÒN - NHA TRANG – CITY TOUR – BÌNH BA - VINPEARLAND, 3N4Đ,</span></li>
									<li><p>Phương tiện vận chuyển:</p><span>Đi xe giường nằm</span></li>
									<li><p>Ngày khởi hành:</p><span>20/02/2020</span></li>
									<li><p>Điểm khởi hành:</p><span>Hồ Chí Minh</span></li>
								</ul>
							</div>
						</div>
						<div class="col-md-6">
							<div class="txt-tour"> 
								<ul>
									<li><p>Mã tour:</p><span>SGVP-NT-3N4D</span></li>
									<li><p>Thời gian: </p><span>4 ngày 3 đêm</span></li>
									<li><p>Điểm kết thúc:</p><span>Hồ Chí Minh</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="info-book">
					<h3>Danh sách khách hàng đi tour</h3>
					<div class="tb-scroll">
						<table class="table table-bordered table-hover dt-responsive w-100 table-per">
					        <thead>
						        <tr>
						            <th>STT</th>
						            <th>Họ tên (*)</th>
						            <th>Ngày sinh (*)</th>
						            <th>Địa chỉ</th>
						            <th>Điện thoại</th>
						            <th>Giới tính</th>
						            <th>Loại khách</th>
						            <th>Độ tuổi</th>
						            <th>Phòng đơn</th>
						            <th>Visa</th>
						            <th>Chất lượng phòng</th>
						            <th>Thành tiền</th>
						        </tr>
					        </thead>
					        <tbody>
						        <tr>
						            <td class="text-center">1</td>
						            <td><span>Nguyễn Hồng Ngọc</span></td>
						            <td><span>20/03/2020</span></td>
						            <td><span>Hoàng Mai, Hà Nội</span></td>
						            <td><span>0123456789</span></td>
						            <td>Nam</td>
						            <td>Việt Nam</td>
						            <td>người lớn</td>
						            <td>Không</td>
						            <td class="text-center">Không</td>
						            <td class="text-center">5*</td>
						            <td class="text-center">5.000.000 đ</td>
						        </tr>
					        </tbody>
						</table>
					</div>
					<div class="total-per">
						<ul>
							<li class="d-flex w-100">
								<p>Tổng tiền</p>
								<p>5.00.000đ</p>
							</li>
							<li class="d-flex w-100">
								<p>Hình thức thanh toán</p>
								<p>Chuyển khoản qua ngân hàng</p>
							</li>
						</ul>
					</div>
				</div>
				<div class="info-book">
					<h3>Thông tin khách hàng</h3>
					<div class="row">
						<div class="col-md-4">
							<div class="txt-tour">
								<ul>
									<li><p style="flex: 0 0 135px;">Họ tên:</p><span> Nguyễn Hồng Ngọc</span></li>
									<li><p style="flex: 0 0 135px;">Email:</p><span> hongngoc123@gmail.com</span></li>
									<li><p style="flex: 0 0 135px;">Điện thoại khác:</p><span>0123456789</span></li>
									<li><p style="flex: 0 0 135px;">Ghi chú:</p><span>Đặt vé kèm các dịch vụ</span></li>
									<li><p style="flex: 0 0 135px;"></p><span></span></li>
								</ul>
							</div>
						</div>
						<div class="col-md-8">
							<div class="txt-tour">
								<ul>
									<li><p style="flex: 0 0 135px;">Địa chỉ:</p><span> ngõ 295, đường Lĩnh Nam, quận Hoàng Mai, Hà Nội</span></li>
									<li><p style="flex: 0 0 135px;">Điện thoại:</p><span>0123456789</span></li>
									<li><p style="flex: 0 0 135px;">Số khách: </p><span>01 (01 người lớn, 0 trẻ em)</span></li>
									<li><p style="flex: 0 0 135px;">Tổng tiền:</p><span>5.000.00đ</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="info-book">
					<h3>Chuyển khoản qua ngân hàng sau</h3>
					<div class="row">
						<div class="col-md-4">
							<div class="txt-tour">
								<ul>
									<li><p style="flex: 0 0 135px;">Ngân hàng:</p><span>ACB</span></li>
									<li><p style="flex: 0 0 135px;">Chủ tài khoản:</p><span>Nguyễn Văn Ty</span></li>
									<li><p style="flex: 0 0 135px;">Số tài khoản:</p><span>0123456789</span></li>
								</ul>
							</div>
						</div>
						<div class="col-md-4">
							<div class="txt-tour">
								<ul>
									<li><p style="flex: 0 0 135px;">Ngân hàng:</p><span>ACB</span></li>
									<li><p style="flex: 0 0 135px;">Chủ tài khoản:</p><span>Nguyễn Văn Ty</span></li>
									<li><p style="flex: 0 0 135px;">Số tài khoản:</p><span>0123456789</span></li>
								</ul>
							</div>
						</div>
						<div class="col-md-4">
							<div class="txt-tour">
								<ul>
									<li><p style="flex: 0 0 135px;">Ngân hàng:</p><span>ACB</span></li>
									<li><p style="flex: 0 0 135px;">Chủ tài khoản:</p><span>Nguyễn Văn Ty</span></li>
									<li><p style="flex: 0 0 135px;">Số tài khoản:</p><span>0123456789</span></li>
								</ul>
							</div>
						</div>
						<div class="col-md-12">
							<div class="txt-tour text-center">
								<ul>
									<li><p style="flex: 0 0 100%;"><label style="color: red;">*</label> Nội dung chuyển khoản: “Tên + Thanh toán + Mã tour”</p></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="info-book text-center">
					<div class="notice-done">
						<p>Chúc mừng quý khách đã đặt tour thành công.</p>
						<p>Quý khách vui lòng vào Email của mình để kiểm tra thông tin đặt tour của du lịch Ocean đã gửi và thanh toán trong thời gian giữ vé là 24h</p>
						<p>Xin chân thành cám ơn!</p>
					</div> 	
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>