<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Tin tức</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="news" class="pt-50 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="news-big">
						<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-1.png" class="img-fluid w-100" alt=""></a></div>
						<div class="info">
							<div class="date">20/03/2020</div>
							<h1><a title="" href="new-detail.php">Sự tích về Miếu Bà Phi Yến và câu chuyện Hoàng Tử Cải bị ném xuống biển</a></h1>
							<div class="desc">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting
							</div>
						</div>
					</div>
					<div class="new-small">
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-3.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-3.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="avarta"><a title="" href="new-detail.php"><img src="images/new-3.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info">
								<h3><a title="" href="new-detail.php">4 lý do visa Pháp bị từ chối phổ biến nhất và nguyên tắc khắc phục</a></h3>
								<label>20/03/2020</label>
								<div class="desc">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
								</div>
							</div>
						</div>
						<div class="item">
							<div class="pagination w-100">
								<ul class="list-inline w-100 text-center">
									<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-left"></i></a></li>
									<li class="list-inline-item"><a title="" href="" class="active">1</a></li>
									<li class="list-inline-item"><a title="" href="">2</a></li>
									<li class="list-inline-item"><a title="" href="">3</a></li>
									<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-right"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="side-bar sticky-top">
						<div class="title-bar text-uppercase">Tin tức mới nhất</div>
						<div class="list-new-bar">
							<div class="new-bar">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/bar-1.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info"><h4><a title="" href="new-detail.php">Điều kiện xin visa du lịch Châu Âu – Visa Schengen bạn cần biết</a></h4></div>
							</div>
							<div class="new-bar">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/bar-2.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info"><h4><a title="" href="new-detail.php">Điều kiện xin visa du lịch Châu Âu – Visa Schengen bạn cần biết</a></h4></div>
							</div>
							<div class="new-bar">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/bar-1.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info"><h4><a title="" href="new-detail.php">Điều kiện xin visa du lịch Châu Âu – Visa Schengen bạn cần biết</a></h4></div>
							</div>
							<div class="new-bar">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/bar-2.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info"><h4><a title="" href="new-detail.php">Điều kiện xin visa du lịch Châu Âu – Visa Schengen bạn cần biết</a></h4></div>
							</div>
							<div class="new-bar">
								<div class="avarta"><a title="" href="new-detail.php"><img src="images/bar-1.png" class="img-fluid w-100" alt=""></a></div>
								<div class="info"><h4><a title="" href="new-detail.php">Điều kiện xin visa du lịch Châu Âu – Visa Schengen bạn cần biết</a></h4></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>