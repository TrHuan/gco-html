<?php include 'header.php';?>
<main>
	<section id="breadcrumbs">
		<div class="container">
			<div class="bread">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="" href="index.php">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Dịch vụ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="service" class="pt-50 pb-50">
		<h1 class="d-none">CÔNG TY TNHH TMDV DU LỊCH OCEAN</h1>
		<div class="container">
			<div class="list-service">
				<div class="row">
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-kh.php"><img src="images/srv-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-kh.php">Đặt phòng khách sạn</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-thuexe.php"><img src="images/srv-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-thuexe.php">Dịch vụ thuê xe</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-sukien.php"><img src="images/srv-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-sukien.php">Tổ chức sự kiện</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-building.php"><img src="images/srv-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-building.php">Team Building</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-building.php"><img src="images/srv-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-building.php">Thuê vật dụng teambuilding</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-mc.php"><img src="images/srv-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-mc.php">Thuê MC - HDV</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-building.php"><img src="images/srv-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-building.php">Team Building</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-thuevatdung.php"><img src="images/srv-1.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-thuevatdung.php">Thuê vật dụng teambuilding</a></h3></div>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="item-service">
							<div class="avarta"><a title="" href="service-mc.php"><img src="images/srv-2.png" class="img-fluid w-100" alt=""></a></div>
							<div class="info text-center"><h3><a title="" href="service-mc.php">Thuê MC - HDV</a></h3></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="pagination w-100">
							<ul class="list-inline w-100 text-center">
								<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-left"></i></a></li>
								<li class="list-inline-item"><a title="" href="" class="active">1</a></li>
								<li class="list-inline-item"><a title="" href="">2</a></li>
								<li class="list-inline-item"><a title="" href="">3</a></li>
								<li class="list-inline-item"><a title="" href=""><i class="fa fa-angle-double-right"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>
<?php include 'footer.php';?>